"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Play, RotateCcw, Download, Eye, EyeOff } from "lucide-react"
import AutomataVisualizer from "./automata-visualizer"
import ConversionSteps from "./conversion-steps"
import { convertRegexToNFA } from "@/lib/regex-algorithms"

interface RegexConverterProps {
  type: "regex-nfa"
}

export default function RegexConverter({ type }: RegexConverterProps) {
  const [regex, setRegex] = useState("")
  const [resultAutomata, setResultAutomata] = useState(null)
  const [conversionSteps, setConversionSteps] = useState([])
  const [currentStep, setCurrentStep] = useState(0)
  const [showSteps, setShowSteps] = useState(true)
  const [isConverting, setIsConverting] = useState(false)

  const exampleRegexes = {
    "regex-nfa": ["(a|b)*a", "(a|b)*abb", "a(b|c)*d"],
  }

  const handleConvert = useCallback(async () => {
    if (!regex.trim()) return

    setIsConverting(true)
    try {
      let result
      result = convertRegexToNFA(regex)

      setResultAutomata(result.automata)
      setConversionSteps(result.steps)
      setCurrentStep(0)
    } catch (error) {
      console.error("Conversion error:", error)
    } finally {
      setIsConverting(false)
    }
  }, [regex])

  const handleReset = () => {
    setResultAutomata(null)
    setConversionSteps([])
    setCurrentStep(0)
    setRegex("")
  }

  const loadExample = (example) => {
    setRegex(example)
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Input Panel */}
      <Card className="lg:col-span-1">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">Regular Expression Input</CardTitle>
          <CardDescription>Enter a regular expression to convert to NFA</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Regular Expression</label>
            <Input
              placeholder="e.g., (a|b)*a, (a|b)*abb"
              value={regex}
              onChange={(e) => setRegex(e.target.value)}
              className="font-mono"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Examples</label>
            <div className="flex flex-wrap gap-2">
              {exampleRegexes[type].map((example, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => loadExample(example)}
                  className="font-mono text-xs"
                >
                  {example}
                </Button>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleConvert} disabled={!regex.trim() || isConverting}>
              <Play className="w-4 h-4 mr-2" />
              Convert
            </Button>
            <Button variant="outline" onClick={handleReset}>
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
          </div>

          <div className="space-y-2 text-xs text-gray-600">
            <Separator />
            <div className="font-semibold">Supported Operators:</div>
            <div>• * (Kleene star)</div>
            <div>• + (One or more)</div>
            <div>• | (Union/OR)</div>
            <div>• () (Grouping)</div>
            <div>• Concatenation (implicit)</div>
          </div>

          {resultAutomata && (
            <div className="space-y-2">
              <Separator />
              <div className="text-sm text-gray-600">
                <div>States: {resultAutomata.states.length}</div>
                <div>Transitions: {Object.keys(resultAutomata.transitions).length}</div>
                <div>Accept States: {resultAutomata.acceptStates.length}</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Visualization Panel */}
      <Card className="lg:col-span-1">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>NFA Visualization</CardTitle>
              <CardDescription>Generated automata from regular expression</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => setShowSteps(!showSteps)}>
                {showSteps ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                Steps
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {regex && (
            <div className="mb-4 p-3 bg-gray-50 rounded-lg">
              <div className="text-sm font-medium text-gray-700 mb-1">Input Regular Expression:</div>
              <div className="font-mono text-lg">{regex}</div>
            </div>
          )}

          {resultAutomata && (
            <div className="mb-4">
              <Badge variant="default" className="mb-2">
                Generated NFA
              </Badge>
              <AutomataVisualizer automata={resultAutomata} />
            </div>
          )}

          {showSteps && conversionSteps.length > 0 && (
            <ConversionSteps steps={conversionSteps} currentStep={currentStep} onStepChange={setCurrentStep} />
          )}

          {!resultAutomata && (
            <div className="w-full h-64 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center text-gray-500">
              Enter a regular expression and click Convert to see the automata
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
