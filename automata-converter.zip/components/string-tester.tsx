"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Play, RotateCcw, CheckCircle, XCircle, Zap } from "lucide-react"
import InteractiveAutomataVisualizer from "./interactive-automata-visualizer"
import { testStringOnAutomata } from "@/lib/string-testing"

interface StringTesterProps {
  selectedExample: any
}

export default function StringTester({ selectedExample }: StringTesterProps) {
  const [testString, setTestString] = useState("")
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [testResult, setTestResult] = useState(null)
  const [activePath, setActivePath] = useState([])
  const [activeTransitions, setActiveTransitions] = useState([])

  const handleTest = useCallback(async () => {
    if (!selectedExample || testString === null) return

    const result = testStringOnAutomata(selectedExample.automata, testString)
    setTestResult(result)
    setCurrentStep(0)
    setActivePath([])
    setActiveTransitions([])
  }, [selectedExample, testString])

  const handleAutoPlay = useCallback(() => {
    if (!testResult) return

    setIsPlaying(true)
    let step = 0

    const interval = setInterval(() => {
      if (step >= testResult.path.length) {
        setIsPlaying(false)
        clearInterval(interval)
        return
      }

      const pathStep = testResult.path[step]
      setCurrentStep(step)
      setActivePath(pathStep.currentStates)
      setActiveTransitions(pathStep.transitions || [])
      step++
    }, 1200)
  }, [testResult])

  const handleReset = () => {
    setIsPlaying(false)
    setCurrentStep(0)
    setActivePath([])
    setActiveTransitions([])
    setTestResult(null)
    setTestString("")
  }

  if (!selectedExample) {
    return (
      <Card className="bg-gradient-to-br from-orange-50 to-red-100 border-orange-200">
        <CardHeader>
          <CardTitle className="text-orange-800">String Testing</CardTitle>
          <CardDescription className="text-orange-600">
            Select an example from the Examples tab to test strings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-orange-600">
            <Zap className="w-16 h-16 mx-auto mb-4 opacity-50" />
            <p className="text-lg">No automata selected</p>
            <p className="text-sm opacity-75">Please choose an example first</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-orange-50 to-red-100 border-orange-200">
        <CardHeader>
          {selectedExample?.type === "regex-nfa" && (
            <div className="bg-gradient-to-r from-pink-50 to-rose-50 border border-pink-200 p-3 rounded-lg mb-4">
              <div className="text-sm font-semibold text-pink-800 mb-1">Regular Expression:</div>
              <div className="font-mono text-lg text-pink-700 bg-white px-3 py-2 rounded border">
                {selectedExample.regex}
              </div>
            </div>
          )}
          <CardTitle className="flex items-center gap-2 text-orange-800">
            <Play className="w-5 h-5" />
            String Testing: {selectedExample.title}
            {selectedExample.type === "regex-nfa" && (
              <Badge className="bg-gradient-to-r from-pink-500 to-rose-500 text-white border-0 text-xs">Regex</Badge>
            )}
          </CardTitle>
          <CardDescription className="text-orange-700">
            Test strings with auto-play visualization and final state highlighting
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <Input
                placeholder="Enter string to test (leave empty for ε)"
                value={testString}
                onChange={(e) => setTestString(e.target.value)}
                className="font-mono border-orange-300 focus:border-orange-500"
              />
            </div>
            <Button
              onClick={handleTest}
              disabled={!selectedExample}
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
            >
              Test String
            </Button>
            {testResult && (
              <>
                <Button
                  onClick={handleAutoPlay}
                  disabled={isPlaying}
                  className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Auto-Play
                </Button>
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="border-orange-300 text-orange-700 hover:bg-orange-50 bg-transparent"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
              </>
            )}
          </div>

          <div className="flex flex-wrap gap-2">
            <span className="text-sm font-medium text-orange-800">Quick Tests:</span>
            {selectedExample.testStrings?.map((str, idx) => (
              <Button
                key={idx}
                variant="outline"
                size="sm"
                onClick={() => setTestString(str)}
                className="font-mono text-xs border-orange-300 text-orange-700 hover:bg-orange-50"
              >
                {str === "" ? "ε" : str}
              </Button>
            ))}
          </div>

          {testResult && (
            <div className="flex items-center gap-4 p-4 rounded-lg border bg-white/80 backdrop-blur-sm">
              <div className="flex items-center gap-2">
                {testResult.accepted ? (
                  <CheckCircle className="w-6 h-6 text-green-600" />
                ) : (
                  <XCircle className="w-6 h-6 text-red-600" />
                )}
                <span className="font-semibold text-lg">
                  String "{testString || "ε"}" is {testResult.accepted ? "ACCEPTED" : "REJECTED"}
                </span>
              </div>
              <Badge
                className={`${
                  testResult.accepted
                    ? "bg-gradient-to-r from-green-500 to-emerald-500"
                    : "bg-gradient-to-r from-red-500 to-pink-500"
                } text-white border-0`}
              >
                {testResult.accepted ? "✓ Accept" : "✗ Reject"}
              </Badge>
              {isPlaying && (
                <Badge className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0 animate-pulse">
                  Auto-Playing
                </Badge>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-gradient-to-br from-blue-50 to-indigo-100 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-800">Automata Visualization</CardTitle>
          <CardDescription className="text-blue-700">
            {isPlaying
              ? `Step ${currentStep + 1} of ${testResult?.path.length || 0} - Auto-playing execution`
              : "Interactive diagram with final state highlighting"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-white/80 backdrop-blur-sm rounded-lg p-4">
            <InteractiveAutomataVisualizer
              automata={selectedExample.automata}
              width={700}
              height={400}
              highlightedStates={isPlaying ? activePath : selectedExample.automata.acceptStates}
              highlightedTransitions={activeTransitions}
              finalStateHighlight={!isPlaying}
              autoPlay={isPlaying}
              readonly={isPlaying}
            />
          </div>

          {testResult && (
            <div className="mt-4 space-y-3">
              <div className="text-sm font-semibold text-blue-800">Execution Path:</div>
              <div className="flex flex-wrap gap-2">
                {testResult.path.map((step, idx) => (
                  <div
                    key={idx}
                    className={`px-3 py-2 rounded-lg text-xs font-mono border ${
                      idx === currentStep
                        ? "bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-blue-300"
                        : idx < currentStep
                          ? "bg-gradient-to-r from-green-500 to-emerald-500 text-white border-green-300"
                          : "bg-white border-gray-300 text-gray-700"
                    }`}
                  >
                    {step.symbol === "" ? "ε" : step.symbol || "start"} → {step.currentStates.join(",")}
                  </div>
                ))}
              </div>
              {testResult.accepted && (
                <div className="bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200 p-3 rounded-lg">
                  <div className="text-sm font-semibold text-blue-800 mb-1">Final States Reached:</div>
                  <div className="flex gap-2">
                    {testResult.finalStates
                      .filter((state) => selectedExample.automata.acceptStates.includes(state))
                      .map((state) => (
                        <Badge key={state} className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white border-0">
                          {state}
                        </Badge>
                      ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
