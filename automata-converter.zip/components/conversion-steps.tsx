"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { ChevronLeft, ChevronRight, Play, Pause, SkipForward } from "lucide-react"

interface ConversionStepsProps {
  steps: any[]
  currentStep: number
  onStepChange: (step: number) => void
}

export default function ConversionSteps({ steps, currentStep, onStepChange }: ConversionStepsProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [playSpeed, setPlaySpeed] = useState(1500)

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isPlaying && currentStep < steps.length - 1) {
      interval = setInterval(() => {
        onStepChange(currentStep + 1)
      }, playSpeed)
    } else if (currentStep >= steps.length - 1) {
      setIsPlaying(false)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isPlaying, currentStep, steps.length, playSpeed, onStepChange])

  const handlePrevious = () => {
    if (currentStep > 0) {
      onStepChange(currentStep - 1)
    }
  }

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      onStepChange(currentStep + 1)
    }
  }

  const handlePlay = () => {
    setIsPlaying(!isPlaying)
  }

  const handleSkipToEnd = () => {
    onStepChange(steps.length - 1)
    setIsPlaying(false)
  }

  if (!steps.length) return null

  const step = steps[currentStep]

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">Conversion Algorithm Steps</CardTitle>
            <CardDescription>
              Step {currentStep + 1} of {steps.length} - {step?.type?.replace("_", " ").toUpperCase()}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              {step?.algorithm || "Processing"}
            </Badge>
            <select
              value={playSpeed}
              onChange={(e) => setPlaySpeed(Number(e.target.value))}
              className="text-xs border rounded px-2 py-1"
            >
              <option value={3000}>Slow</option>
              <option value={1500}>Normal</option>
              <option value={800}>Fast</option>
            </select>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Controls */}
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" onClick={handlePrevious} disabled={currentStep === 0}>
            <ChevronLeft className="w-4 h-4" />
          </Button>

          <Button size="sm" variant="outline" onClick={handlePlay} disabled={currentStep >= steps.length - 1}>
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          </Button>

          <Button size="sm" variant="outline" onClick={handleNext} disabled={currentStep === steps.length - 1}>
            <ChevronRight className="w-4 h-4" />
          </Button>

          <Button size="sm" variant="outline" onClick={handleSkipToEnd} disabled={currentStep >= steps.length - 1}>
            <SkipForward className="w-4 h-4" />
          </Button>

          {/* Progress Bar */}
          <div className="flex-1 bg-gray-200 rounded-full h-2 ml-4">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        <Separator />

        {/* Step Content */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h4 className="font-semibold text-lg">{step?.title}</h4>
            {step?.complexity && (
              <Badge variant={step.complexity === "High" ? "destructive" : "secondary"}>{step.complexity}</Badge>
            )}
          </div>

          <p className="text-gray-700">{step?.description}</p>

          {step?.details && (
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
              <h5 className="font-semibold text-sm text-blue-800 mb-2">Algorithm Details:</h5>
              <pre className="text-sm font-mono whitespace-pre-wrap text-blue-700">{step.details}</pre>
            </div>
          )}

          {step?.newStates && step.newStates.length > 0 && (
            <div className="bg-green-50 border border-green-200 p-3 rounded-lg">
              <h5 className="text-sm font-semibold text-green-800 mb-2">New States Created:</h5>
              <div className="flex flex-wrap gap-2">
                {step.newStates.map((state: string, index: number) => (
                  <Badge key={index} variant="secondary" className="text-xs bg-green-100 text-green-800">
                    {state}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {step?.transitions && step.transitions.length > 0 && (
            <div className="bg-purple-50 border border-purple-200 p-3 rounded-lg">
              <h5 className="text-sm font-semibold text-purple-800 mb-2">Transitions Added:</h5>
              <div className="space-y-1">
                {step.transitions.map((transition: string, index: number) => (
                  <div key={index} className="text-sm font-mono bg-purple-100 text-purple-800 p-2 rounded">
                    {transition}
                  </div>
                ))}
              </div>
            </div>
          )}

          {step?.stateMapping && (
            <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-lg">
              <h5 className="text-sm font-semibold text-yellow-800 mb-2">State Mapping:</h5>
              <div className="text-sm font-mono text-yellow-700">
                {Object.entries(step.stateMapping).map(([dfaState, nfaStates]: [string, any]) => (
                  <div key={dfaState} className="mb-1">
                    {dfaState} ← {Array.isArray(nfaStates) ? `{${nfaStates.join(", ")}}` : nfaStates}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Step Navigation */}
        <div className="flex justify-between items-center pt-4 border-t">
          <div className="text-sm text-gray-500">
            {currentStep === 0 && "Starting conversion process"}
            {currentStep > 0 && currentStep < steps.length - 1 && "Conversion in progress"}
            {currentStep === steps.length - 1 && "Conversion complete!"}
          </div>
          <div className="text-sm text-gray-500">{Math.round(((currentStep + 1) / steps.length) * 100)}% Complete</div>
        </div>
      </CardContent>
    </Card>
  )
}
