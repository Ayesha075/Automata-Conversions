"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play } from "lucide-react"
import InteractiveAutomataVisualizer from "./interactive-automata-visualizer"

const examples = [
  {
    id: "example1",
    title: "NFA: Strings ending with 'ab'",
    description: "Classic NFA that accepts all strings ending with 'ab'",
    type: "nfa-dfa",
    difficulty: "Easy",
    testStrings: ["ab", "aab", "bab", "abab", "ba", "a", "b", ""],
    automata: {
      states: ["q0", "q1", "q2"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q0", "q1"], b: ["q0"] },
        q1: { b: ["q2"] },
        q2: {},
      },
      startState: "q0",
      acceptStates: ["q2"],
      positions: {
        q0: { x: 100, y: 150 },
        q1: { x: 300, y: 100 },
        q2: { x: 500, y: 150 },
      },
    },
  },
  {
    id: "example2",
    title: "ε-NFA: Contains 'abb' substring",
    description: "ε-NFA that accepts strings containing 'abb' as substring",
    type: "enfa-dfa",
    difficulty: "Medium",
    testStrings: ["abb", "aabb", "abba", "xabby", "ab", "ba", ""],
    automata: {
      states: ["q0", "q1", "q2", "q3", "q4"],
      alphabet: ["a", "b", "ε"],
      transitions: {
        q0: { ε: ["q1"], a: ["q0"], b: ["q0"] },
        q1: { a: ["q2"] },
        q2: { b: ["q3"] },
        q3: { b: ["q4"] },
        q4: { a: ["q4"], b: ["q4"] },
      },
      startState: "q0",
      acceptStates: ["q4"],
      positions: {
        q0: { x: 80, y: 150 },
        q1: { x: 200, y: 100 },
        q2: { x: 320, y: 100 },
        q3: { x: 440, y: 100 },
        q4: { x: 560, y: 150 },
      },
    },
  },
  {
    id: "example3",
    title: "NFA: Even number of a's",
    description: "NFA that accepts strings with even number of a's",
    type: "nfa-dfa",
    difficulty: "Easy",
    testStrings: ["", "b", "bb", "aa", "aba", "bab", "aabb"],
    automata: {
      states: ["q0", "q1"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q1"], b: ["q0"] },
        q1: { a: ["q0"], b: ["q1"] },
      },
      startState: "q0",
      acceptStates: ["q0"],
      positions: {
        q0: { x: 200, y: 120 },
        q1: { x: 400, y: 120 },
      },
    },
  },
  {
    id: "example4",
    title: "NFA: Binary strings divisible by 3",
    description: "NFA that accepts binary numbers divisible by 3",
    type: "nfa-dfa",
    difficulty: "Hard",
    testStrings: ["0", "11", "110", "1001", "1100", "1111", "10010"],
    automata: {
      states: ["q0", "q1", "q2"],
      alphabet: ["0", "1"],
      transitions: {
        q0: { "0": ["q0"], "1": ["q1"] },
        q1: { "0": ["q2"], "1": ["q0"] },
        q2: { "0": ["q1"], "1": ["q2"] },
      },
      startState: "q0",
      acceptStates: ["q0"],
      positions: {
        q0: { x: 300, y: 80 },
        q1: { x: 200, y: 200 },
        q2: { x: 400, y: 200 },
      },
    },
  },
  {
    id: "example5",
    title: "ε-NFA: (a|b)*a(a|b)",
    description: "ε-NFA for strings ending with 'a' followed by any symbol",
    type: "enfa-dfa",
    difficulty: "Medium",
    testStrings: ["aa", "ab", "baa", "aba", "aab", "a", "b", "ba"],
    automata: {
      states: ["q0", "q1", "q2", "q3"],
      alphabet: ["a", "b", "ε"],
      transitions: {
        q0: { a: ["q0", "q1"], b: ["q0"] },
        q1: { ε: ["q2"] },
        q2: { a: ["q3"], b: ["q3"] },
        q3: {},
      },
      startState: "q0",
      acceptStates: ["q3"],
      positions: {
        q0: { x: 100, y: 150 },
        q1: { x: 250, y: 100 },
        q2: { x: 400, y: 100 },
        q3: { x: 550, y: 150 },
      },
    },
  },
  {
    id: "example6",
    title: "NFA: Complex pattern (a*b+c)",
    description: "NFA for zero or more a's, one or more b's, then c",
    type: "nfa-dfa",
    difficulty: "Hard",
    testStrings: ["bc", "abc", "aabc", "abbc", "abbbc", "ac", "c", "ab"],
    automata: {
      states: ["q0", "q1", "q2"],
      alphabet: ["a", "b", "c"],
      transitions: {
        q0: { a: ["q0"], b: ["q1"] },
        q1: { b: ["q1"], c: ["q2"] },
        q2: {},
      },
      startState: "q0",
      acceptStates: ["q2"],
      positions: {
        q0: { x: 150, y: 150 },
        q1: { x: 350, y: 150 },
        q2: { x: 550, y: 150 },
      },
    },
  },
  {
    id: "example7",
    title: "Regex: (a|b)*a",
    description: "Regular expression for strings ending with 'a'",
    type: "regex-nfa",
    difficulty: "Easy",
    testStrings: ["a", "aa", "ba", "aba", "bba", "b", "ab", "bb"],
    regex: "(a|b)*a",
    automata: {
      states: ["q0", "q1"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q0", "q1"], b: ["q0"] },
        q1: {},
      },
      startState: "q0",
      acceptStates: ["q1"],
      positions: {
        q0: { x: 200, y: 150 },
        q1: { x: 450, y: 150 },
      },
    },
  },
  {
    id: "example8",
    title: "Regex: a+",
    description: "Simple regex for one or more a's - basic pattern",
    type: "regex-nfa",
    difficulty: "Easy",
    testStrings: ["a", "aa", "aaa", "aaaa", "", "b", "ab", "ba"],
    regex: "a+",
    automata: {
      states: ["q0", "q1"],
      alphabet: ["a"],
      transitions: {
        q0: { a: ["q1"] },
        q1: { a: ["q1"] },
      },
      startState: "q0",
      acceptStates: ["q1"],
      positions: {
        q0: { x: 200, y: 150 },
        q1: { x: 450, y: 150 },
      },
    },
  },
  {
    id: "example9",
    title: "Regex: (ab|ba)*",
    description: "Medium complexity - alternating patterns with Kleene star",
    type: "regex-nfa",
    difficulty: "Medium",
    testStrings: ["", "ab", "ba", "abab", "baba", "abba", "baab", "a", "b", "aba"],
    regex: "(ab|ba)*",
    automata: {
      states: ["q0", "q1", "q2"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q1"], b: ["q2"] },
        q1: { b: ["q0"] },
        q2: { a: ["q0"] },
      },
      startState: "q0",
      acceptStates: ["q0"],
      positions: {
        q0: { x: 300, y: 100 },
        q1: { x: 200, y: 200 },
        q2: { x: 400, y: 200 },
      },
    },
  },
  {
    id: "example10",
    title: "Regex: (a|b)*abb(a|b)*",
    description: "Complex pattern - contains 'abb' substring with wildcards",
    type: "regex-nfa",
    difficulty: "Hard",
    testStrings: ["abb", "aabb", "abba", "babbab", "xabby", "abbabb", "ab", "ba", ""],
    regex: "(a|b)*abb(a|b)*",
    automata: {
      states: ["q0", "q1", "q2", "q3", "q4"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q0", "q1"], b: ["q0"] },
        q1: { b: ["q2"] },
        q2: { b: ["q3"] },
        q3: { a: ["q3", "q4"], b: ["q3"] },
        q4: { a: ["q4"], b: ["q4"] },
      },
      startState: "q0",
      acceptStates: ["q3", "q4"],
      positions: {
        q0: { x: 100, y: 150 },
        q1: { x: 250, y: 100 },
        q2: { x: 400, y: 100 },
        q3: { x: 550, y: 150 },
        q4: { x: 700, y: 200 },
      },
    },
  },
]

interface ExampleSelectorProps {
  onExampleSelect: (example: any) => void
}

export default function ExampleSelector({ onExampleSelect }: ExampleSelectorProps) {
  return (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold mb-2">Interactive Automata Examples</h2>
        <p className="text-gray-600">Drag nodes, test strings, and convert between automata types</p>
        <div className="flex justify-center gap-4 mt-4">
          <Badge className="bg-gradient-to-r from-emerald-400 to-teal-500 text-white">6 NFA/ε-NFA Examples</Badge>
          <Badge className="bg-gradient-to-r from-pink-400 to-rose-500 text-white">4 Regex Examples</Badge>
          <Badge className="bg-gradient-to-r from-blue-400 to-indigo-500 text-white">10 Total Examples</Badge>
        </div>
      </div>

      <div className="grid gap-6">
        {examples.map((example) => (
          <Card key={example.id} className="overflow-hidden">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg">{example.title}</CardTitle>
                  <CardDescription>{example.description}</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    variant={
                      example.difficulty === "Easy"
                        ? "secondary"
                        : example.difficulty === "Medium"
                          ? "default"
                          : "destructive"
                    }
                  >
                    {example.difficulty}
                  </Badge>
                  <Badge variant="outline">
                    {example.type === "nfa-dfa" ? "NFA" : example.type === "enfa-dfa" ? "ε-NFA" : "Regex"}
                  </Badge>
                  <Button size="sm" onClick={() => onExampleSelect(example)} className="ml-2">
                    <Play className="w-4 h-4 mr-1" />
                    Try
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {example.type === "regex-nfa" && (
                <div className="bg-gradient-to-r from-pink-50 to-rose-50 border border-pink-200 p-3 rounded-lg mb-4">
                  <div className="text-sm font-semibold text-pink-800 mb-1">Regular Expression:</div>
                  <div className="font-mono text-lg text-pink-700 bg-white px-3 py-2 rounded border">
                    {example.regex}
                  </div>
                  <div className="text-xs text-pink-600 mt-2">
                    {example.difficulty === "Easy" && "Basic pattern matching"}
                    {example.difficulty === "Medium" && "Intermediate operations with grouping"}
                    {example.difficulty === "Hard" && "Complex pattern with multiple operations"}
                  </div>
                </div>
              )}
              <div className="bg-white rounded-lg border p-4 mb-4">
                <InteractiveAutomataVisualizer
                  automata={example.automata}
                  width={example.difficulty === "Hard" ? 750 : 600}
                  height={example.difficulty === "Hard" ? 300 : 250}
                  readonly={true}
                  showCorrectDiagram={true}
                />
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                <div>
                  <strong>States:</strong> {example.automata.states.join(", ")}
                </div>
                <div>
                  <strong>Alphabet:</strong> {example.automata.alphabet.filter((s) => s !== "ε").join(", ")}
                </div>
                <div>
                  <strong>Start:</strong> {example.automata.startState}
                </div>
                <div>
                  <strong>Accept:</strong> {example.automata.acceptStates.join(", ")}
                </div>
              </div>

              <div>
                <div className="text-sm font-semibold mb-2">Test Strings:</div>
                <div className="flex flex-wrap gap-2">
                  {example.testStrings.map((str, idx) => (
                    <Badge key={idx} variant="outline" className="font-mono text-xs">
                      {str === "" ? "ε" : str}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
