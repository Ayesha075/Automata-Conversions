// String testing algorithms for automata

export interface TestResult {
  accepted: boolean
  path: PathStep[]
  finalStates: string[]
}

export interface PathStep {
  symbol: string
  currentStates: string[]
  transitions?: string[]
}

export function testStringOnAutomata(automata: any, inputString: string): TestResult {
  const symbols = inputString === "" ? [""] : inputString.split("")
  const path: PathStep[] = []

  // Start with initial state(s)
  let currentStates = new Set([automata.startState])

  // Add epsilon closure if it's an epsilon-NFA
  if (automata.alphabet.includes("ε")) {
    currentStates = new Set(computeEpsilonClosure(automata, Array.from(currentStates)))
  }

  path.push({
    symbol: "start",
    currentStates: Array.from(currentStates),
  })

  // Process each symbol
  for (let i = 0; i < symbols.length; i++) {
    const symbol = symbols[i]
    const nextStates = new Set<string>()
    const transitions: string[] = []

    // For empty string, we don't process any symbols
    if (symbol === "" && inputString === "") {
      break
    }

    // Find all possible next states
    for (const state of currentStates) {
      if (automata.transitions[state] && automata.transitions[state][symbol]) {
        const targets = automata.transitions[state][symbol]
        const targetArray = Array.isArray(targets) ? targets : [targets]

        for (const target of targetArray) {
          nextStates.add(target)
          transitions.push(`${state}-${symbol}-${target}`)
        }
      }
    }

    // Add epsilon closure if it's an epsilon-NFA
    if (automata.alphabet.includes("ε") && nextStates.size > 0) {
      const withEpsilon = computeEpsilonClosure(automata, Array.from(nextStates))
      nextStates.clear()
      withEpsilon.forEach((state) => nextStates.add(state))
    }

    currentStates = nextStates
    path.push({
      symbol,
      currentStates: Array.from(currentStates),
      transitions,
    })

    // If no states reachable, string is rejected
    if (currentStates.size === 0) {
      break
    }
  }

  // Check if any final state is an accept state
  const finalStates = Array.from(currentStates)
  const accepted = finalStates.some((state) => automata.acceptStates.includes(state))

  return {
    accepted,
    path,
    finalStates,
  }
}

function computeEpsilonClosure(automata: any, states: string[]): string[] {
  const closure = new Set(states)
  const stack = [...states]

  while (stack.length > 0) {
    const current = stack.pop()!
    if (automata.transitions[current] && automata.transitions[current]["ε"]) {
      const epsilonTargets = automata.transitions[current]["ε"]
      const targets = Array.isArray(epsilonTargets) ? epsilonTargets : [epsilonTargets]

      for (const target of targets) {
        if (!closure.has(target)) {
          closure.add(target)
          stack.push(target)
        }
      }
    }
  }

  return Array.from(closure).sort()
}
