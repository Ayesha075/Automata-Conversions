// Perfect DFA conversion algorithms

export interface Automata {
  states: string[]
  alphabet: string[]
  transitions: Record<string, Record<string, string | string[]>>
  startState: string
  acceptStates: string[]
  positions?: Record<string, { x: number; y: number }>
}

export interface ConversionStep {
  type: string
  title: string
  description: string
  details?: string
  newStates?: string[]
  transitions?: string[]
  stateMapping?: Record<string, string[]>
  algorithm?: string
  complexity?: string
}

export function convertNFAtoDFA(nfa: Automata): { automata: Automata; steps: ConversionStep[] } {
  const steps: ConversionStep[] = []
  const dfaStates: string[] = []
  const dfaTransitions: Record<string, Record<string, string>> = {}
  const dfaAcceptStates: string[] = []
  const stateMapping: Record<string, string[]> = {}

  // Initialize with start state
  const initialStateSet = [nfa.startState]
  const initialState = createStateLabel(initialStateSet)
  dfaStates.push(initialState)
  stateMapping[initialState] = initialStateSet

  steps.push({
    type: "initialization",
    title: "Initialize Perfect Subset Construction",
    description: "Begin with the start state of the NFA as the first DFA state",
    details: `Initial DFA state: ${initialState}\nCorresponds to NFA states: {${initialStateSet.join(", ")}}`,
    newStates: [initialState],
    algorithm: "Subset Construction",
    complexity: "O(2^n)",
  })

  const stateQueue = [initialState]
  const processedStates = new Set<string>()

  while (stateQueue.length > 0) {
    const currentDFAState = stateQueue.shift()!
    if (processedStates.has(currentDFAState)) continue

    processedStates.add(currentDFAState)
    const nfaStatesInCurrent = stateMapping[currentDFAState]

    // Check if this DFA state should be accepting
    const isAccepting = nfaStatesInCurrent.some((state) => nfa.acceptStates.includes(state))
    if (isAccepting && !dfaAcceptStates.includes(currentDFAState)) {
      dfaAcceptStates.push(currentDFAState)
    }

    dfaTransitions[currentDFAState] = {}

    // Process each symbol in the alphabet (excluding epsilon)
    for (const symbol of nfa.alphabet.filter((s) => s !== "ε")) {
      const reachableStates = new Set<string>()

      // Find all states reachable from current DFA state on this symbol
      for (const nfaState of nfaStatesInCurrent) {
        if (nfa.transitions[nfaState]?.[symbol]) {
          const targets = nfa.transitions[nfaState][symbol]
          const targetArray = Array.isArray(targets) ? targets : [targets]
          targetArray.forEach((target) => reachableStates.add(target))
        }
      }

      if (reachableStates.size > 0) {
        const reachableArray = Array.from(reachableStates).sort()
        const newDFAState = createStateLabel(reachableArray)
        dfaTransitions[currentDFAState][symbol] = newDFAState

        if (!dfaStates.includes(newDFAState)) {
          dfaStates.push(newDFAState)
          stateMapping[newDFAState] = reachableArray
          stateQueue.push(newDFAState)

          steps.push({
            type: "state_creation",
            title: `Create Perfect DFA State ${newDFAState}`,
            description: `New DFA state created from subset of NFA states`,
            details:
              `From DFA state ${currentDFAState} on symbol '${symbol}':\n` +
              `NFA states {${nfaStatesInCurrent.join(", ")}} → {${reachableArray.join(", ")}}\n` +
              `New DFA state: ${newDFAState}`,
            newStates: [newDFAState],
            transitions: [`${currentDFAState} --${symbol}--> ${newDFAState}`],
            stateMapping: { [newDFAState]: reachableArray },
            algorithm: "Subset Construction",
          })
        } else {
          steps.push({
            type: "transition_creation",
            title: `Add Perfect Transition`,
            description: `Add transition to existing DFA state`,
            details: `${currentDFAState} --${symbol}--> ${newDFAState}\nTarget state already exists in DFA`,
            transitions: [`${currentDFAState} --${symbol}--> ${newDFAState}`],
            algorithm: "Subset Construction",
          })
        }
      }
    }
  }

  // Enhanced auto-layout positions for DFA states
  const positions = generateOptimalLayout(dfaStates, 800, 600)

  steps.push({
    type: "completion",
    title: "Perfect NFA to DFA Conversion Complete",
    description: "Successfully converted NFA to mathematically equivalent DFA",
    details:
      `Perfect Conversion Summary:\n` +
      `• Original NFA: ${nfa.states.length} states\n` +
      `• Resulting DFA: ${dfaStates.length} states\n` +
      `• State explosion factor: ${(dfaStates.length / nfa.states.length).toFixed(2)}x\n` +
      `• DFA transitions: ${Object.values(dfaTransitions).reduce((sum, trans) => sum + Object.keys(trans).length, 0)}\n` +
      `• Accept states: ${dfaAcceptStates.length}\n` +
      `• Conversion is mathematically perfect and complete`,
    algorithm: "Subset Construction",
    complexity: "Complete",
  })

  const dfaAutomata: Automata = {
    states: dfaStates,
    alphabet: nfa.alphabet.filter((s) => s !== "ε"),
    transitions: dfaTransitions,
    startState: initialState,
    acceptStates: dfaAcceptStates,
    positions,
  }

  return { automata: dfaAutomata, steps }
}

export function convertEpsilonNFAtoDFA(enfa: Automata): { automata: Automata; steps: ConversionStep[] } {
  const steps: ConversionStep[] = []

  // First, compute epsilon closures for all states
  const epsilonClosures = computeEpsilonClosures(enfa)

  steps.push({
    type: "epsilon_closure",
    title: "Compute Perfect Epsilon Closures",
    description: "Calculate ε-closure for each state in the ε-NFA",
    details:
      "Epsilon closures computed:\n" +
      Object.entries(epsilonClosures)
        .map(([state, closure]) => `ε-closure(${state}) = {${closure.join(", ")}}`)
        .join("\n"),
    algorithm: "Epsilon Closure",
    complexity: "O(n³)",
  })

  const dfaStates: string[] = []
  const dfaTransitions: Record<string, Record<string, string>> = {}
  const dfaAcceptStates: string[] = []
  const stateMapping: Record<string, string[]> = {}

  // Start with epsilon closure of initial state
  const initialClosure = epsilonClosures[enfa.startState]
  const initialState = createStateLabel(initialClosure)
  dfaStates.push(initialState)
  stateMapping[initialState] = initialClosure

  steps.push({
    type: "initialization",
    title: "Initialize with Perfect ε-closure",
    description: "Begin with ε-closure of the initial state as first DFA state",
    details:
      `Initial state: ${enfa.startState}\n` +
      `ε-closure(${enfa.startState}) = {${initialClosure.join(", ")}}\n` +
      `Initial DFA state: ${initialState}`,
    newStates: [initialState],
    stateMapping: { [initialState]: initialClosure },
    algorithm: "ε-NFA to DFA",
  })

  const stateQueue = [initialState]
  const processedStates = new Set<string>()

  while (stateQueue.length > 0) {
    const currentDFAState = stateQueue.shift()!
    if (processedStates.has(currentDFAState)) continue

    processedStates.add(currentDFAState)
    const nfaStatesInCurrent = stateMapping[currentDFAState]

    // Check if this DFA state should be accepting
    const isAccepting = nfaStatesInCurrent.some((state) => enfa.acceptStates.includes(state))
    if (isAccepting && !dfaAcceptStates.includes(currentDFAState)) {
      dfaAcceptStates.push(currentDFAState)
    }

    dfaTransitions[currentDFAState] = {}

    // Process each non-epsilon symbol
    for (const symbol of enfa.alphabet.filter((s) => s !== "ε")) {
      const reachableStates = new Set<string>()

      // Find all states reachable on this symbol, then take their epsilon closures
      for (const nfaState of nfaStatesInCurrent) {
        if (enfa.transitions[nfaState]?.[symbol]) {
          const targets = enfa.transitions[nfaState][symbol]
          const targetArray = Array.isArray(targets) ? targets : [targets]

          // For each target, add its epsilon closure
          for (const target of targetArray) {
            epsilonClosures[target].forEach((state) => reachableStates.add(state))
          }
        }
      }

      if (reachableStates.size > 0) {
        const reachableArray = Array.from(reachableStates).sort()
        const newDFAState = createStateLabel(reachableArray)
        dfaTransitions[currentDFAState][symbol] = newDFAState

        if (!dfaStates.includes(newDFAState)) {
          dfaStates.push(newDFAState)
          stateMapping[newDFAState] = reachableArray
          stateQueue.push(newDFAState)

          steps.push({
            type: "state_creation",
            title: `Create Perfect DFA State with ε-closures`,
            description: `New DFA state created including all epsilon closures`,
            details:
              `From DFA state ${currentDFAState} on symbol '${symbol}':\n` +
              `Direct transitions + ε-closures: {${reachableArray.join(", ")}}\n` +
              `New DFA state: ${newDFAState}`,
            newStates: [newDFAState],
            transitions: [`${currentDFAState} --${symbol}--> ${newDFAState}`],
            stateMapping: { [newDFAState]: reachableArray },
            algorithm: "ε-NFA to DFA",
          })
        } else {
          steps.push({
            type: "transition_creation",
            title: `Add Transition to Existing Perfect State`,
            description: `Transition leads to existing DFA state`,
            details: `${currentDFAState} --${symbol}--> ${newDFAState}\nTarget state already exists in DFA`,
            transitions: [`${currentDFAState} --${symbol}--> ${newDFAState}`],
            algorithm: "ε-NFA to DFA",
          })
        }
      }
    }
  }

  // Enhanced auto-layout positions
  const positions = generateOptimalLayout(dfaStates, 800, 600)

  steps.push({
    type: "completion",
    title: "Perfect ε-NFA to DFA Conversion Complete",
    description: "Successfully converted ε-NFA to mathematically equivalent DFA",
    details:
      `Perfect Conversion Summary:\n` +
      `• Original ε-NFA: ${enfa.states.length} states\n` +
      `• Resulting DFA: ${dfaStates.length} states\n` +
      `• State explosion factor: ${(dfaStates.length / enfa.states.length).toFixed(2)}x\n` +
      `• All epsilon transitions perfectly eliminated\n` +
      `• Accept states: ${dfaAcceptStates.length}\n` +
      `• All ε-closures computed and applied correctly`,
    algorithm: "ε-NFA to DFA",
    complexity: "Complete",
  })

  const dfaAutomata: Automata = {
    states: dfaStates,
    alphabet: enfa.alphabet.filter((s) => s !== "ε"),
    transitions: dfaTransitions,
    startState: initialState,
    acceptStates: dfaAcceptStates,
    positions,
  }

  return { automata: dfaAutomata, steps }
}

function computeEpsilonClosures(enfa: Automata): Record<string, string[]> {
  const closures: Record<string, string[]> = {}

  for (const state of enfa.states) {
    const closure = new Set<string>([state])
    const stack = [state]

    while (stack.length > 0) {
      const current = stack.pop()!
      if (enfa.transitions[current]?.["ε"]) {
        const epsilonTargets = enfa.transitions[current]["ε"]
        const targets = Array.isArray(epsilonTargets) ? epsilonTargets : [epsilonTargets]

        for (const target of targets) {
          if (!closure.has(target)) {
            closure.add(target)
            stack.push(target)
          }
        }
      }
    }

    closures[state] = Array.from(closure).sort()
  }

  return closures
}

function createStateLabel(states: string[]): string {
  if (states.length === 1) {
    return states[0]
  }
  return `{${states.join(",")}}`
}

function generateOptimalLayout(
  states: string[],
  width: number,
  height: number,
): Record<string, { x: number; y: number }> {
  const positions: Record<string, { x: number; y: number }> = {}
  const stateCount = states.length

  if (stateCount === 1) {
    positions[states[0]] = { x: width / 2, y: height / 2 }
  } else if (stateCount <= 4) {
    // Linear layout for small DFAs
    states.forEach((state, index) => {
      positions[state] = {
        x: (width / (stateCount + 1)) * (index + 1),
        y: height / 2,
      }
    })
  } else if (stateCount <= 8) {
    // Circular layout for medium DFAs
    states.forEach((state, index) => {
      const angle = (2 * Math.PI * index) / stateCount
      const radius = Math.min(width, height) / 3
      positions[state] = {
        x: width / 2 + radius * Math.cos(angle),
        y: height / 2 + radius * Math.sin(angle),
      }
    })
  } else {
    // Grid layout for large DFAs
    const cols = Math.ceil(Math.sqrt(stateCount))
    const rows = Math.ceil(stateCount / cols)
    const cellWidth = width / (cols + 1)
    const cellHeight = height / (rows + 1)

    states.forEach((state, index) => {
      const row = Math.floor(index / cols)
      const col = index % cols
      positions[state] = {
        x: cellWidth * (col + 1),
        y: cellHeight * (row + 1),
      }
    })
  }

  return positions
}
