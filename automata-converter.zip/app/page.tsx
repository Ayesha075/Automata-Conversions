"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TrendingUp, Zap, GitBranch, Cpu, Users, Activity } from "lucide-react"
import AutomataConverter from "@/components/automata-converter"
import ExampleSelector from "@/components/example-selector"
import StringTester from "@/components/string-tester"
import Dashboard from "@/components/dashboard"

export default function HomePage() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [selectedExample, setSelectedExample] = useState(null)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 bg-clip-text text-transparent mb-3">
            Advanced Automata Theory Tool
          </h1>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Interactive diagrams with auto-play, colorful dashboard, and intelligent state highlighting
          </p>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-6 mb-8 bg-white/80 backdrop-blur-sm">
            <TabsTrigger
              value="dashboard"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-500 data-[state=active]:to-blue-500 data-[state=active]:text-white"
            >
              <Activity className="w-4 h-4 mr-2" />
              Dashboard
            </TabsTrigger>
            <TabsTrigger
              value="examples"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-500 data-[state=active]:to-emerald-500 data-[state=active]:text-white"
            >
              <Users className="w-4 h-4 mr-2" />
              Examples
            </TabsTrigger>
            <TabsTrigger
              value="string-test"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-red-500 data-[state=active]:text-white"
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              String Test
            </TabsTrigger>
            <TabsTrigger
              value="nfa-dfa"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-500 data-[state=active]:to-cyan-500 data-[state=active]:text-white"
            >
              <GitBranch className="w-4 h-4 mr-2" />
              NFA → DFA
            </TabsTrigger>
            <TabsTrigger
              value="enfa-dfa"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-500 data-[state=active]:to-purple-500 data-[state=active]:text-white"
            >
              <Zap className="w-4 h-4 mr-2" />
              ε-NFA → DFA
            </TabsTrigger>
            <TabsTrigger
              value="regex-nfa"
              className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-pink-500 data-[state=active]:to-rose-500 data-[state=active]:text-white"
            >
              <Cpu className="w-4 h-4 mr-2" />
              Regex → NFA
            </TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard">
            <Dashboard selectedExample={selectedExample} onExampleSelect={setSelectedExample} />
          </TabsContent>

          <TabsContent value="examples">
            <ExampleSelector onExampleSelect={setSelectedExample} />
          </TabsContent>

          <TabsContent value="string-test">
            <StringTester selectedExample={selectedExample} />
          </TabsContent>

          <TabsContent value="nfa-dfa">
            <AutomataConverter type="nfa-dfa" initialExample={selectedExample} />
          </TabsContent>

          <TabsContent value="enfa-dfa">
            <AutomataConverter type="enfa-dfa" initialExample={selectedExample} />
          </TabsContent>

          <TabsContent value="regex-nfa">
            <AutomataConverter type="regex-nfa" initialExample={selectedExample} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
