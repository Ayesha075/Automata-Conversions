"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, RotateCcw, Zap, GitBranch, Users, TrendingUp, Activity, Clock } from "lucide-react"
import InteractiveAutomataVisualizer from "./interactive-automata-visualizer"

const examples = [
  {
    id: "example1",
    title: "NFA: Strings ending with 'ab'",
    type: "nfa-dfa",
    difficulty: "Easy",
    color: "from-emerald-300 to-teal-400",
    bgColor: "bg-gradient-to-br from-emerald-50 to-teal-50",
    automata: {
      states: ["q0", "q1", "q2"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q0", "q1"], b: ["q0"] },
        q1: { b: ["q2"] },
        q2: {},
      },
      startState: "q0",
      acceptStates: ["q2"],
      positions: {
        q0: { x: 100, y: 150 },
        q1: { x: 300, y: 100 },
        q2: { x: 500, y: 150 },
      },
    },
  },
  {
    id: "example2",
    title: "ε-NFA: Contains 'abb'",
    type: "enfa-dfa",
    difficulty: "Medium",
    color: "from-sky-300 to-blue-400",
    bgColor: "bg-gradient-to-br from-sky-50 to-blue-50",
    automata: {
      states: ["q0", "q1", "q2", "q3", "q4"],
      alphabet: ["a", "b", "ε"],
      transitions: {
        q0: { ε: ["q1"], a: ["q0"], b: ["q0"] },
        q1: { a: ["q2"] },
        q2: { b: ["q3"] },
        q3: { b: ["q4"] },
        q4: { a: ["q4"], b: ["q4"] },
      },
      startState: "q0",
      acceptStates: ["q4"],
      positions: {
        q0: { x: 80, y: 150 },
        q1: { x: 200, y: 100 },
        q2: { x: 320, y: 100 },
        q3: { x: 440, y: 100 },
        q4: { x: 560, y: 150 },
      },
    },
  },
  {
    id: "example3",
    title: "NFA: Even number of a's",
    type: "nfa-dfa",
    difficulty: "Easy",
    color: "from-violet-300 to-purple-400",
    bgColor: "bg-gradient-to-br from-violet-50 to-purple-50",
    automata: {
      states: ["q0", "q1"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q1"], b: ["q0"] },
        q1: { a: ["q0"], b: ["q1"] },
      },
      startState: "q0",
      acceptStates: ["q0"],
      positions: {
        q0: { x: 200, y: 120 },
        q1: { x: 400, y: 120 },
      },
    },
  },
  {
    id: "example4",
    title: "Regex: a+",
    type: "regex-nfa",
    difficulty: "Easy",
    color: "from-pink-300 to-rose-400",
    bgColor: "bg-gradient-to-br from-pink-50 to-rose-50",
    regex: "a+",
    automata: {
      states: ["q0", "q1"],
      alphabet: ["a"],
      transitions: {
        q0: { a: ["q1"] },
        q1: { a: ["q1"] },
      },
      startState: "q0",
      acceptStates: ["q1"],
      positions: {
        q0: { x: 200, y: 150 },
        q1: { x: 450, y: 150 },
      },
    },
  },
  {
    id: "example5",
    title: "Regex: (ab|ba)*",
    type: "regex-nfa",
    difficulty: "Medium",
    color: "from-orange-300 to-amber-400",
    bgColor: "bg-gradient-to-br from-orange-50 to-amber-50",
    regex: "(ab|ba)*",
    automata: {
      states: ["q0", "q1", "q2"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q1"], b: ["q2"] },
        q1: { b: ["q0"] },
        q2: { a: ["q0"] },
      },
      startState: "q0",
      acceptStates: ["q0"],
      positions: {
        q0: { x: 300, y: 100 },
        q1: { x: 200, y: 200 },
        q2: { x: 400, y: 200 },
      },
    },
  },
  {
    id: "example6",
    title: "Regex: (a|b)*abb(a|b)*",
    type: "regex-nfa",
    difficulty: "Hard",
    color: "from-red-300 to-pink-400",
    bgColor: "bg-gradient-to-br from-red-50 to-pink-50",
    regex: "(a|b)*abb(a|b)*",
    automata: {
      states: ["q0", "q1", "q2", "q3", "q4"],
      alphabet: ["a", "b"],
      transitions: {
        q0: { a: ["q0", "q1"], b: ["q0"] },
        q1: { b: ["q2"] },
        q2: { b: ["q3"] },
        q3: { a: ["q3", "q4"], b: ["q3"] },
        q4: { a: ["q4"], b: ["q4"] },
      },
      startState: "q0",
      acceptStates: ["q3", "q4"],
      positions: {
        q0: { x: 100, y: 150 },
        q1: { x: 250, y: 100 },
        q2: { x: 400, y: 100 },
        q3: { x: 550, y: 150 },
        q4: { x: 700, y: 200 },
      },
    },
  },
]

interface DashboardProps {
  selectedExample: any
  onExampleSelect: (example: any) => void
}

export default function Dashboard({ selectedExample, onExampleSelect }: DashboardProps) {
  const [autoPlayExample, setAutoPlayExample] = useState(null)
  const [isAutoPlaying, setIsAutoPlaying] = useState(false)
  const [currentExampleIndex, setCurrentExampleIndex] = useState(0)
  const [stats, setStats] = useState({
    totalExamples: 10,
    conversionsToday: 58,
    activeUsers: 142,
    successRate: 100.0,
  })

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isAutoPlaying) {
      interval = setInterval(() => {
        setCurrentExampleIndex((prev) => (prev + 1) % examples.length)
        setAutoPlayExample(examples[(currentExampleIndex + 1) % examples.length])
      }, 3500)
    }
    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isAutoPlaying, currentExampleIndex])

  const handleAutoPlay = () => {
    if (isAutoPlaying) {
      setIsAutoPlaying(false)
      setAutoPlayExample(null)
    } else {
      setIsAutoPlaying(true)
      setAutoPlayExample(examples[currentExampleIndex])
    }
  }

  const handleReset = () => {
    setIsAutoPlaying(false)
    setAutoPlayExample(null)
    setCurrentExampleIndex(0)
  }

  return (
    <div className="space-y-8">
      {/* Light Stats Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-sky-100 to-blue-200 text-slate-800 border-0 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Examples</CardTitle>
            <Users className="h-4 w-4 opacity-70" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalExamples}</div>
            <p className="text-xs opacity-70">NFA, ε-NFA & Regex patterns</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-emerald-100 to-teal-200 text-slate-800 border-0 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conversions Today</CardTitle>
            <TrendingUp className="h-4 w-4 opacity-70" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.conversionsToday}</div>
            <p className="text-xs opacity-70">+15% from yesterday</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-violet-100 to-purple-200 text-slate-800 border-0 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <Activity className="h-4 w-4 opacity-70" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.activeUsers}</div>
            <p className="text-xs opacity-70">Learning automata theory</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-100 to-orange-200 text-slate-800 border-0 shadow-md">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Success Rate</CardTitle>
            <Zap className="h-4 w-4 opacity-70" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.successRate}%</div>
            <p className="text-xs opacity-70">Conversion accuracy</p>
          </CardContent>
        </Card>
      </div>

      {/* Auto-Play Section */}
      <Card className="bg-gradient-to-br from-slate-50 to-gray-100 border-slate-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2 text-slate-800">
                <Clock className="w-5 h-5" />
                Auto-Play Demonstration
              </CardTitle>
              <CardDescription className="text-slate-600">
                Watch automata examples cycle automatically with final state highlighting
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleAutoPlay}
                className={`${
                  isAutoPlaying
                    ? "bg-gradient-to-r from-rose-400 to-pink-500 hover:from-rose-500 hover:to-pink-600"
                    : "bg-gradient-to-r from-emerald-400 to-teal-500 hover:from-emerald-500 hover:to-teal-600"
                } text-white border-0`}
              >
                {isAutoPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                {isAutoPlaying ? "Pause" : "Auto-Play"}
              </Button>
              <Button
                variant="outline"
                onClick={handleReset}
                className="border-slate-300 text-slate-700 bg-white hover:bg-slate-50"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {autoPlayExample ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold text-slate-800">{autoPlayExample.title}</h3>
                  <div className="flex gap-2 mt-1">
                    <Badge className={`bg-gradient-to-r ${autoPlayExample.color} text-white border-0`}>
                      {autoPlayExample.difficulty}
                    </Badge>
                    <Badge variant="outline" className="border-slate-300 text-slate-700">
                      {autoPlayExample.type === "nfa-dfa"
                        ? "NFA"
                        : autoPlayExample.type === "enfa-dfa"
                          ? "ε-NFA"
                          : "Regex"}
                    </Badge>
                    {isAutoPlaying && (
                      <Badge className="bg-gradient-to-r from-sky-400 to-blue-500 text-white border-0 animate-pulse">
                        Auto-Playing
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="text-sm text-slate-600">
                  Example {currentExampleIndex + 1} of {examples.length}
                </div>
              </div>

              {autoPlayExample?.type === "regex-nfa" && (
                <div className={`${autoPlayExample.bgColor} p-3 rounded-lg border border-slate-200 mb-4`}>
                  <strong className="text-slate-800">Regular Expression:</strong>{" "}
                  <span className="font-mono text-lg text-slate-700 bg-white px-2 py-1 rounded border ml-2">
                    {autoPlayExample.regex}
                  </span>
                  <div className="text-xs text-slate-600 mt-2">
                    {autoPlayExample.difficulty === "Easy" && "🟢 Basic pattern matching"}
                    {autoPlayExample.difficulty === "Medium" && "🟡 Intermediate operations with grouping"}
                    {autoPlayExample.difficulty === "Hard" && "🔴 Complex pattern with multiple operations"}
                  </div>
                </div>
              )}

              <div className={`${autoPlayExample.bgColor} rounded-lg p-4 border border-slate-200`}>
                <InteractiveAutomataVisualizer
                  automata={autoPlayExample.automata}
                  width={autoPlayExample.difficulty === "Hard" ? 800 : 700}
                  height={autoPlayExample.difficulty === "Hard" ? 350 : 300}
                  readonly={true}
                  highlightedStates={autoPlayExample.automata.acceptStates}
                  autoPlay={isAutoPlaying}
                  finalStateHighlight={true}
                  showCorrectDiagram={true}
                />
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className={`${autoPlayExample.bgColor} p-3 rounded-lg border border-slate-200`}>
                  <strong className="text-slate-800">States:</strong>{" "}
                  <span className="text-slate-700">{autoPlayExample.automata.states.join(", ")}</span>
                </div>
                <div className={`${autoPlayExample.bgColor} p-3 rounded-lg border border-slate-200`}>
                  <strong className="text-slate-800">Alphabet:</strong>{" "}
                  <span className="text-slate-700">
                    {autoPlayExample.automata.alphabet.filter((s) => s !== "ε").join(", ")}
                  </span>
                </div>
                <div className={`${autoPlayExample.bgColor} p-3 rounded-lg border border-slate-200`}>
                  <strong className="text-slate-800">Start:</strong>{" "}
                  <Badge variant="outline" className="ml-1 border-amber-400 text-amber-700 bg-amber-50">
                    {autoPlayExample.automata.startState}
                  </Badge>
                </div>
                <div className={`${autoPlayExample.bgColor} p-3 rounded-lg border border-slate-200`}>
                  <strong className="text-slate-800">Final States:</strong>{" "}
                  {autoPlayExample.automata.acceptStates.map((state) => (
                    <Badge key={state} className="ml-1 bg-gradient-to-r from-sky-400 to-blue-500 text-white border-0">
                      {state}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-600">
              <Clock className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg">Click Auto-Play to start the demonstration</p>
              <p className="text-sm opacity-75">Final states will be highlighted in blue</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Examples Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {examples.map((example, index) => (
          <Card
            key={example.id}
            className={`${example.bgColor} border-slate-200 shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer transform hover:scale-105`}
            onClick={() => onExampleSelect(example)}
          >
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-slate-800">{example.title}</CardTitle>
                <div className="flex gap-1">
                  <Badge className={`bg-gradient-to-r ${example.color} text-white border-0`}>
                    {example.difficulty}
                  </Badge>
                  {currentExampleIndex === index && isAutoPlaying && (
                    <Badge className="bg-gradient-to-r from-sky-400 to-blue-500 text-white border-0 animate-pulse">
                      Playing
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {example.type === "regex-nfa" && (
                <div className={`${example.bgColor} p-2 rounded-lg border border-slate-200 mb-2`}>
                  <span className="font-medium text-slate-700 text-xs">Regex:</span>{" "}
                  <span className="font-mono text-sm text-slate-800 bg-white px-2 py-1 rounded border">
                    {example.regex}
                  </span>
                  <div className="text-xs text-slate-600 mt-1">
                    {example.difficulty === "Easy" && "🟢 Basic"}
                    {example.difficulty === "Medium" && "🟡 Intermediate"}
                    {example.difficulty === "Hard" && "🔴 Complex"}
                  </div>
                </div>
              )}
              <div className="bg-white/80 backdrop-blur-sm rounded-lg p-3 mb-4 border border-slate-200">
                <InteractiveAutomataVisualizer
                  automata={example.automata}
                  width={example.difficulty === "Hard" ? 450 : 400}
                  height={200}
                  readonly={true}
                  highlightedStates={example.automata.acceptStates}
                  finalStateHighlight={true}
                  showCorrectDiagram={true}
                />
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="font-medium text-slate-700">States:</span>
                  <span className="text-slate-600">{example.automata.states.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-slate-700">Transitions:</span>
                  <span className="text-slate-600">
                    {Object.values(example.automata.transitions).reduce(
                      (sum, trans) => sum + Object.keys(trans).length,
                      0,
                    )}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium text-slate-700">Final States:</span>
                  <div className="flex gap-1">
                    {example.automata.acceptStates.map((state) => (
                      <Badge
                        key={state}
                        className="bg-gradient-to-r from-sky-400 to-blue-500 text-white border-0 text-xs"
                      >
                        {state}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              <Button
                className={`w-full mt-4 bg-gradient-to-r ${example.color} hover:opacity-90 text-white border-0`}
                onClick={(e) => {
                  e.stopPropagation()
                  onExampleSelect(example)
                }}
              >
                <GitBranch className="w-4 h-4 mr-2" />
                Try This Example
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
