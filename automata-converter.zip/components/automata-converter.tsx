"use client"

import { useState, useCallback, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Play, RotateCcw, ArrowRight, Zap, Eye, EyeOff } from "lucide-react"
import InteractiveAutomataVisualizer from "./interactive-automata-visualizer"
import ConversionSteps from "./conversion-steps"
import { convertNFAtoDFA, convertEpsilonNFAtoDFA } from "@/lib/automata-algorithms"

interface AutomataConverterProps {
  type: "nfa-dfa" | "enfa-dfa" | "regex-nfa"
  initialExample?: any
}

export default function AutomataConverter({ type, initialExample }: AutomataConverterProps) {
  const [sourceAutomata, setSourceAutomata] = useState(null)
  const [targetAutomata, setTargetAutomata] = useState(null)
  const [conversionSteps, setConversionSteps] = useState([])
  const [currentStep, setCurrentStep] = useState(0)
  const [isConverting, setIsConverting] = useState(false)
  const [isConverted, setIsConverted] = useState(false)
  const [showPath, setShowPath] = useState(false)
  const [pathHighlight, setPathHighlight] = useState({ states: [], transitions: [] })

  useEffect(() => {
    if (initialExample && initialExample.type === type) {
      setSourceAutomata(initialExample.automata)
      setTargetAutomata(null)
      setConversionSteps([])
      setCurrentStep(0)
      setIsConverted(false)
      setShowPath(false)
      setPathHighlight({ states: [], transitions: [] })
    }
  }, [initialExample, type])

  const calculateDiagramSize = (automata) => {
    if (!automata) return { width: 600, height: 400 }

    const stateCount = automata.states.length
    const baseWidth = 600
    const baseHeight = 400

    // Increase size based on number of states
    const scaleFactor = Math.max(1, Math.sqrt(stateCount / 3))

    return {
      width: Math.min(Math.max(baseWidth * scaleFactor, 700), 1200),
      height: Math.min(Math.max(baseHeight * scaleFactor, 500), 800),
    }
  }

  const findPathToAcceptStates = (automata) => {
    if (!automata || !automata.acceptStates.length) return { states: [], transitions: [] }

    const visited = new Set()
    const pathStates = new Set([automata.startState])
    const pathTransitions = new Set()

    // BFS to find all reachable accept states
    const queue = [{ state: automata.startState, path: [automata.startState], transitions: [] }]

    while (queue.length > 0) {
      const { state, path, transitions } = queue.shift()

      if (visited.has(state)) continue
      visited.add(state)

      // If this is an accept state, mark the entire path
      if (automata.acceptStates.includes(state)) {
        path.forEach((s) => pathStates.add(s))
        transitions.forEach((t) => pathTransitions.add(t))
      }

      // Explore neighbors
      if (automata.transitions[state]) {
        Object.entries(automata.transitions[state]).forEach(([symbol, targets]) => {
          const targetArray = Array.isArray(targets) ? targets : [targets]
          targetArray.forEach((target) => {
            if (!visited.has(target)) {
              const newTransition = `${state}-${symbol}-${target}`
              queue.push({
                state: target,
                path: [...path, target],
                transitions: [...transitions, newTransition],
              })
            }
          })
        })
      }
    }

    return {
      states: Array.from(pathStates),
      transitions: Array.from(pathTransitions),
    }
  }

  const handleConvert = useCallback(async () => {
    if (!sourceAutomata) return

    setIsConverting(true)
    try {
      let result
      if (type === "nfa-dfa") {
        result = convertNFAtoDFA(sourceAutomata)
      } else if (type === "enfa-dfa") {
        result = convertEpsilonNFAtoDFA(sourceAutomata)
      }

      if (result) {
        setTargetAutomata(result.automata)
        setConversionSteps(result.steps)
        setCurrentStep(0)
        setIsConverted(true)

        // Calculate path highlighting
        const pathInfo = findPathToAcceptStates(result.automata)
        setPathHighlight(pathInfo)
      }
    } catch (error) {
      console.error("Conversion error:", error)
    } finally {
      setIsConverting(false)
    }
  }, [sourceAutomata, type])

  const handleReset = () => {
    setSourceAutomata(null)
    setTargetAutomata(null)
    setConversionSteps([])
    setCurrentStep(0)
    setIsConverted(false)
    setShowPath(false)
    setPathHighlight({ states: [], transitions: [] })
  }

  const togglePathHighlight = () => {
    setShowPath(!showPath)
  }

  const getTitle = () => {
    switch (type) {
      case "nfa-dfa":
        return "NFA to DFA Conversion"
      case "enfa-dfa":
        return "ε-NFA to DFA Conversion"
      case "regex-nfa":
        return "Regular Expression to NFA"
      default:
        return "Automata Conversion"
    }
  }

  const getDescription = () => {
    switch (type) {
      case "nfa-dfa":
        return "Convert using subset construction algorithm with adaptive diagram sizing"
      case "enfa-dfa":
        return "Convert using epsilon closure algorithm with path highlighting"
      case "regex-nfa":
        return "Convert using Thompson's construction"
      default:
        return "Interactive automata conversion"
    }
  }

  const sourceDiagramSize = calculateDiagramSize(sourceAutomata)
  const targetDiagramSize = calculateDiagramSize(targetAutomata)

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                {type === "nfa-dfa" && <ArrowRight className="w-5 h-5" />}
                {type === "enfa-dfa" && <Zap className="w-5 h-5" />}
                {getTitle()}
              </CardTitle>
              <CardDescription>{getDescription()}</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleConvert}
                disabled={!sourceAutomata || isConverting}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Play className="w-4 h-4 mr-2" />
                {isConverting ? "Converting..." : "Convert"}
              </Button>
              {targetAutomata && (
                <Button variant="outline" onClick={togglePathHighlight}>
                  {showPath ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
                  {showPath ? "Hide Path" : "Show Path"}
                </Button>
              )}
              <Button variant="outline" onClick={handleReset}>
                <RotateCcw className="w-4 h-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Source Automata */}
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">
                  Source {type === "nfa-dfa" ? "NFA" : type === "enfa-dfa" ? "ε-NFA" : "Automata"}
                </CardTitle>
                <CardDescription>Drag nodes to rearrange the diagram</CardDescription>
              </div>
              {sourceAutomata && (
                <div className="flex gap-2">
                  <Badge variant="secondary">{sourceAutomata.states.length} states</Badge>
                  <Badge variant="outline">
                    {Object.values(sourceAutomata.transitions).reduce(
                      (sum, trans) => sum + Object.keys(trans).length,
                      0,
                    )}{" "}
                    transitions
                  </Badge>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent className="flex-1">
            {sourceAutomata ? (
              <div className="border rounded-lg overflow-hidden">
                <InteractiveAutomataVisualizer
                  automata={sourceAutomata}
                  width={sourceDiagramSize.width}
                  height={sourceDiagramSize.height}
                  onNodeMove={(nodeId, position) => {
                    setSourceAutomata((prev) => ({
                      ...prev,
                      positions: {
                        ...prev.positions,
                        [nodeId]: position,
                      },
                    }))
                  }}
                />
              </div>
            ) : (
              <div className="w-full h-64 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center text-gray-500">
                Select an example from the Examples tab to get started
              </div>
            )}

            {sourceAutomata && (
              <div className="mt-4 grid grid-cols-2 gap-4 text-sm bg-gray-50 p-3 rounded-lg">
                <div>
                  <strong>States:</strong> {sourceAutomata.states.join(", ")}
                </div>
                <div>
                  <strong>Alphabet:</strong> {sourceAutomata.alphabet.filter((s) => s !== "ε").join(", ")}
                </div>
                <div>
                  <strong>Start:</strong>{" "}
                  <span className="font-mono bg-yellow-100 px-1 rounded">{sourceAutomata.startState}</span>
                </div>
                <div>
                  <strong>Accept:</strong>{" "}
                  {sourceAutomata.acceptStates.map((state) => (
                    <span key={state} className="font-mono bg-green-100 px-1 rounded mr-1">
                      {state}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Target Automata */}
        <Card className="flex flex-col">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">Target DFA</CardTitle>
                <CardDescription>Result with {showPath ? "path highlighting" : "adaptive sizing"}</CardDescription>
              </div>
              {targetAutomata && (
                <div className="flex gap-2">
                  <Badge variant="default">{targetAutomata.states.length} states</Badge>
                  <Badge variant="outline">
                    {Object.values(targetAutomata.transitions).reduce(
                      (sum, trans) => sum + Object.keys(trans).length,
                      0,
                    )}{" "}
                    transitions
                  </Badge>
                  {showPath && (
                    <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                      Path Shown
                    </Badge>
                  )}
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent className="flex-1">
            {targetAutomata ? (
              <div className="border rounded-lg overflow-hidden">
                <InteractiveAutomataVisualizer
                  automata={targetAutomata}
                  width={targetDiagramSize.width}
                  height={targetDiagramSize.height}
                  highlightedStates={showPath ? pathHighlight.states : []}
                  highlightedTransitions={showPath ? pathHighlight.transitions : []}
                  showPathHighlight={showPath}
                />
              </div>
            ) : (
              <div className="w-full h-64 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center text-gray-500">
                {sourceAutomata ? "Click Convert to see the result" : "No conversion result yet"}
              </div>
            )}

            {targetAutomata && (
              <div className="mt-4 space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm bg-gray-50 p-3 rounded-lg">
                  <div>
                    <strong>DFA States:</strong> {targetAutomata.states.length}
                  </div>
                  <div>
                    <strong>Alphabet:</strong> {targetAutomata.alphabet.join(", ")}
                  </div>
                  <div>
                    <strong>Start:</strong>{" "}
                    <span className="font-mono bg-yellow-100 px-2 py-1 rounded border border-yellow-300">
                      {targetAutomata.startState}
                    </span>
                  </div>
                  <div>
                    <strong>Final States:</strong>{" "}
                    {targetAutomata.acceptStates.map((state) => (
                      <span
                        key={state}
                        className="font-mono bg-blue-100 px-2 py-1 rounded mr-1 border-2 border-blue-400 text-blue-800"
                      >
                        {state}
                      </span>
                    ))}
                  </div>
                </div>

                {showPath && pathHighlight.states.length > 0 && (
                  <div className="bg-blue-50 border border-blue-200 p-3 rounded-lg">
                    <div className="text-sm font-semibold text-blue-800 mb-2">Path from Initial to Final States:</div>
                    <div className="flex flex-wrap gap-1">
                      {pathHighlight.states.map((state) => (
                        <Badge
                          key={state}
                          variant="secondary"
                          className="bg-blue-100 text-blue-800 text-xs border border-blue-300"
                        >
                          {state}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="text-xs bg-green-50 border border-green-200 p-3 rounded text-green-800">
                  <strong>✓ Perfect DFA Conversion:</strong> {sourceAutomata?.states.length || 0} NFA states →{" "}
                  {targetAutomata.states.length} DFA states
                  {targetAutomata.states.length > (sourceAutomata?.states.length || 0) && (
                    <span className="text-orange-600 ml-2">(Expected state explosion - mathematically correct)</span>
                  )}
                  <div className="mt-1">
                    <strong>Completeness:</strong> All transitions defined, no missing states, perfect equivalence
                    guaranteed
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Conversion Steps */}
      {isConverted && conversionSteps.length > 0 && (
        <ConversionSteps
          steps={conversionSteps}
          currentStep={currentStep}
          onStepChange={setCurrentStep}
          sourceAutomata={sourceAutomata}
          targetAutomata={targetAutomata}
        />
      )}
    </div>
  )
}
