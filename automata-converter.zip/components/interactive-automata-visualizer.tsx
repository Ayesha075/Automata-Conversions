"use client"

import type React from "react"

import { useRef, useEffect, useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { ZoomIn, ZoomOut, RotateCcw, Download, Maximize2 } from "lucide-react"

interface Position {
  x: number
  y: number
}

interface AutomataVisualizerProps {
  automata: any
  width?: number
  height?: number
  readonly?: boolean
  highlightedStates?: string[]
  highlightedTransitions?: string[]
  showPathHighlight?: boolean
  autoPlay?: boolean
  finalStateHighlight?: boolean
  showCorrectDiagram?: boolean
  onNodeMove?: (nodeId: string, position: Position) => void
}

export default function InteractiveAutomataVisualizer({
  automata,
  width = 600,
  height = 400,
  readonly = false,
  highlightedStates = [],
  highlightedTransitions = [],
  showPathHighlight = false,
  autoPlay = false,
  finalStateHighlight = false,
  showCorrectDiagram = false,
  onNodeMove,
}: AutomataVisualizerProps) {
  const svgRef = useRef<SVGSVGElement>(null)
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [draggedNode, setDraggedNode] = useState<string | null>(null)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const [nodePositions, setNodePositions] = useState<Record<string, Position>>({})
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [animationPhase, setAnimationPhase] = useState(0)

  // Auto-play animation effect
  useEffect(() => {
    if (autoPlay && finalStateHighlight) {
      const interval = setInterval(() => {
        setAnimationPhase((prev) => (prev + 1) % 4)
      }, 800)
      return () => clearInterval(interval)
    }
  }, [autoPlay, finalStateHighlight])

  useEffect(() => {
    if (automata?.positions) {
      setNodePositions(automata.positions)
    } else if (automata?.states) {
      // Enhanced auto-layout for better spacing
      const positions: Record<string, Position> = {}
      const stateCount = automata.states.length

      if (stateCount <= 3) {
        // Linear layout for small automata
        automata.states.forEach((state: string, index: number) => {
          positions[state] = {
            x: (width / (stateCount + 1)) * (index + 1),
            y: height / 2,
          }
        })
      } else if (stateCount <= 6) {
        // Circular layout for medium automata
        automata.states.forEach((state: string, index: number) => {
          const angle = (2 * Math.PI * index) / stateCount
          const radius = Math.min(width, height) / 3
          positions[state] = {
            x: width / 2 + radius * Math.cos(angle),
            y: height / 2 + radius * Math.sin(angle),
          }
        })
      } else {
        // Grid layout for large automata
        const cols = Math.ceil(Math.sqrt(stateCount))
        const rows = Math.ceil(stateCount / cols)
        const cellWidth = width / (cols + 1)
        const cellHeight = height / (rows + 1)

        automata.states.forEach((state: string, index: number) => {
          const row = Math.floor(index / cols)
          const col = index % cols
          positions[state] = {
            x: cellWidth * (col + 1),
            y: cellHeight * (row + 1),
          }
        })
      }
      setNodePositions(positions)
    }
  }, [automata, width, height])

  const handleMouseDown = useCallback(
    (e: React.MouseEvent, nodeId?: string) => {
      if (readonly) return

      const rect = svgRef.current?.getBoundingClientRect()
      if (!rect) return

      const x = (e.clientX - rect.left - pan.x) / zoom
      const y = (e.clientY - rect.top - pan.y) / zoom

      if (nodeId) {
        setDraggedNode(nodeId)
        const nodePos = nodePositions[nodeId]
        setDragOffset({
          x: x - nodePos.x,
          y: y - nodePos.y,
        })
      } else {
        setIsDragging(true)
        setDragOffset({ x: e.clientX - pan.x, y: e.clientY - pan.y })
      }
    },
    [readonly, pan, zoom, nodePositions],
  )

  const handleMouseMove = useCallback(
    (e: React.MouseEvent) => {
      if (draggedNode) {
        const rect = svgRef.current?.getBoundingClientRect()
        if (!rect) return

        const x = (e.clientX - rect.left - pan.x) / zoom - dragOffset.x
        const y = (e.clientY - rect.top - pan.y) / zoom - dragOffset.y

        setNodePositions((prev) => ({
          ...prev,
          [draggedNode]: { x, y },
        }))

        onNodeMove?.(draggedNode, { x, y })
      } else if (isDragging) {
        setPan({
          x: e.clientX - dragOffset.x,
          y: e.clientY - dragOffset.y,
        })
      }
    },
    [draggedNode, isDragging, dragOffset, pan, zoom, onNodeMove],
  )

  const handleMouseUp = useCallback(() => {
    setDraggedNode(null)
    setIsDragging(false)
  }, [])

  const drawArrowMarkers = (svg: SVGSVGElement) => {
    let defs = svg.querySelector("defs")
    if (!defs) {
      defs = document.createElementNS("http://www.w3.org/2000/svg", "defs")
      svg.appendChild(defs)
    }

    // Regular arrow
    if (!defs.querySelector("#arrowhead")) {
      const marker = document.createElementNS("http://www.w3.org/2000/svg", "marker")
      marker.setAttribute("id", "arrowhead")
      marker.setAttribute("markerWidth", "10")
      marker.setAttribute("markerHeight", "7")
      marker.setAttribute("refX", "9")
      marker.setAttribute("refY", "3.5")
      marker.setAttribute("orient", "auto")

      const polygon = document.createElementNS("http://www.w3.org/2000/svg", "polygon")
      polygon.setAttribute("points", "0 0, 10 3.5, 0 7")
      polygon.setAttribute("fill", "#374151")

      marker.appendChild(polygon)
      defs.appendChild(marker)
    }

    // Blue final state arrow
    if (!defs.querySelector("#arrowhead-blue")) {
      const marker = document.createElementNS("http://www.w3.org/2000/svg", "marker")
      marker.setAttribute("id", "arrowhead-blue")
      marker.setAttribute("markerWidth", "12")
      marker.setAttribute("markerHeight", "8")
      marker.setAttribute("refX", "10")
      marker.setAttribute("refY", "4")
      marker.setAttribute("orient", "auto")

      const polygon = document.createElementNS("http://www.w3.org/2000/svg", "polygon")
      polygon.setAttribute("points", "0 0, 12 4, 0 8")
      polygon.setAttribute("fill", "#2563eb")

      marker.appendChild(polygon)
      defs.appendChild(marker)
    }

    // Animated gradient for auto-play
    if (autoPlay && !defs.querySelector("#animatedGradient")) {
      const gradient = document.createElementNS("http://www.w3.org/2000/svg", "radialGradient")
      gradient.setAttribute("id", "animatedGradient")
      gradient.setAttribute("cx", "50%")
      gradient.setAttribute("cy", "50%")
      gradient.setAttribute("r", "50%")

      const stop1 = document.createElementNS("http://www.w3.org/2000/svg", "stop")
      stop1.setAttribute("offset", "0%")
      stop1.setAttribute("stop-color", "#3b82f6")
      stop1.setAttribute("stop-opacity", "0.8")

      const stop2 = document.createElementNS("http://www.w3.org/2000/svg", "stop")
      stop2.setAttribute("offset", "100%")
      stop2.setAttribute("stop-color", "#1d4ed8")
      stop2.setAttribute("stop-opacity", "0.3")

      gradient.appendChild(stop1)
      gradient.appendChild(stop2)
      defs.appendChild(gradient)
    }
  }

  const renderAutomata = () => {
    if (!automata || !svgRef.current || Object.keys(nodePositions).length === 0) return

    const svg = svgRef.current
    svg.innerHTML = ""

    drawArrowMarkers(svg)

    const mainGroup = document.createElementNS("http://www.w3.org/2000/svg", "g")
    mainGroup.setAttribute("transform", `translate(${pan.x}, ${pan.y}) scale(${zoom})`)
    svg.appendChild(mainGroup)

    // Draw transitions first (so they appear behind nodes)
    Object.entries(automata.transitions).forEach(([fromState, transitions]: [string, any]) => {
      Object.entries(transitions).forEach(([symbol, toStates]: [string, any]) => {
        const toStateArray = Array.isArray(toStates) ? toStates : [toStates]
        toStateArray.forEach((toState: string) => {
          const transitionKey = `${fromState}-${symbol}-${toState}`
          const isHighlighted = highlightedTransitions.includes(transitionKey)
          const isToFinalState = finalStateHighlight && automata.acceptStates.includes(toState)
          drawTransition(mainGroup, fromState, toState, symbol, isHighlighted, isToFinalState)
        })
      })
    })

    // Draw nodes
    automata.states.forEach((state: string) => {
      const isHighlighted = highlightedStates.includes(state)
      const isFinalState = finalStateHighlight && automata.acceptStates.includes(state)
      drawNode(mainGroup, state, isHighlighted, isFinalState)
    })
  }

  const drawTransition = (
    parent: SVGGElement,
    fromState: string,
    toState: string,
    symbol: string,
    isHighlighted = false,
    isToFinalState = false,
  ) => {
    const from = nodePositions[fromState]
    const to = nodePositions[toState]
    if (!from || !to) return

    let strokeColor = "#374151"
    let strokeWidth = "2"
    let markerEnd = "url(#arrowhead)"

    if (isToFinalState) {
      strokeColor = "#2563eb"
      strokeWidth = "3"
      markerEnd = "url(#arrowhead-blue)"
    } else if (isHighlighted) {
      strokeColor = "#dc2626"
      strokeWidth = "3"
      markerEnd = "url(#arrowhead)"
    }

    if (fromState === toState) {
      // Self-loop
      const loopRadius = 35
      const cx = from.x
      const cy = from.y - loopRadius - 30

      const loopPath = document.createElementNS("http://www.w3.org/2000/svg", "path")
      loopPath.setAttribute(
        "d",
        `M ${from.x} ${from.y - 30} Q ${cx - loopRadius} ${cy} ${cx} ${cy} Q ${cx + loopRadius} ${cy} ${from.x} ${from.y - 30}`,
      )
      loopPath.setAttribute("stroke", strokeColor)
      loopPath.setAttribute("stroke-width", strokeWidth)
      loopPath.setAttribute("fill", "none")
      loopPath.setAttribute("marker-end", markerEnd)
      if (isToFinalState && autoPlay) {
        loopPath.setAttribute("opacity", (0.7 + animationPhase * 0.1).toString())
      }
      parent.appendChild(loopPath)

      // Self-loop label
      const labelBg = document.createElementNS("http://www.w3.org/2000/svg", "rect")
      const labelWidth = symbol.length * 10 + 12
      labelBg.setAttribute("x", (cx - labelWidth / 2).toString())
      labelBg.setAttribute("y", (cy - 14).toString())
      labelBg.setAttribute("width", labelWidth.toString())
      labelBg.setAttribute("height", "20")
      labelBg.setAttribute("fill", isToFinalState ? "#dbeafe" : isHighlighted ? "#fecaca" : "white")
      labelBg.setAttribute("stroke", strokeColor)
      labelBg.setAttribute("stroke-width", "1")
      labelBg.setAttribute("rx", "4")
      parent.appendChild(labelBg)

      const label = document.createElementNS("http://www.w3.org/2000/svg", "text")
      label.setAttribute("x", cx.toString())
      label.setAttribute("y", (cy - 1).toString())
      label.setAttribute("text-anchor", "middle")
      label.setAttribute("font-family", "Arial, sans-serif")
      label.setAttribute("font-size", "13")
      label.setAttribute("font-weight", "bold")
      label.setAttribute("fill", strokeColor)
      label.textContent = symbol
      parent.appendChild(label)
    } else {
      // Regular transition - NO DOUBLE ARROWS for correct diagrams
      const dx = to.x - from.x
      const dy = to.y - from.y
      const length = Math.sqrt(dx * dx + dy * dy)
      const unitX = dx / length
      const unitY = dy / length

      const startX = from.x + 30 * unitX
      const startY = from.y + 30 * unitY
      const endX = to.x - 30 * unitX
      const endY = to.y - 30 * unitY

      // Single line for correct diagram display
      const line = document.createElementNS("http://www.w3.org/2000/svg", "line")
      line.setAttribute("x1", startX.toString())
      line.setAttribute("y1", startY.toString())
      line.setAttribute("x2", endX.toString())
      line.setAttribute("y2", endY.toString())
      line.setAttribute("stroke", strokeColor)
      line.setAttribute("stroke-width", strokeWidth)
      line.setAttribute("marker-end", markerEnd)
      if (isToFinalState && autoPlay) {
        line.setAttribute("opacity", (0.7 + animationPhase * 0.1).toString())
      }
      parent.appendChild(line)

      // Transition label
      const midX = (startX + endX) / 2
      const midY = (startY + endY) / 2

      // Label background
      const labelBg = document.createElementNS("http://www.w3.org/2000/svg", "rect")
      const labelWidth = symbol.length * 10 + 12
      labelBg.setAttribute("x", (midX - labelWidth / 2).toString())
      labelBg.setAttribute("y", (midY - 14).toString())
      labelBg.setAttribute("width", labelWidth.toString())
      labelBg.setAttribute("height", "20")
      labelBg.setAttribute("fill", isToFinalState ? "#dbeafe" : isHighlighted ? "#fecaca" : "white")
      labelBg.setAttribute("stroke", strokeColor)
      labelBg.setAttribute("stroke-width", "1")
      labelBg.setAttribute("rx", "4")
      parent.appendChild(labelBg)

      const label = document.createElementNS("http://www.w3.org/2000/svg", "text")
      label.setAttribute("x", midX.toString())
      label.setAttribute("y", (midY - 1).toString())
      label.setAttribute("text-anchor", "middle")
      label.setAttribute("font-family", "Arial, sans-serif")
      label.setAttribute("font-size", "13")
      label.setAttribute("font-weight", "bold")
      label.setAttribute("fill", strokeColor)
      label.textContent = symbol
      parent.appendChild(label)
    }
  }

  useEffect(() => {
    renderAutomata()
  }, [automata, nodePositions, zoom, pan, highlightedStates, highlightedTransitions, showPathHighlight, animationPhase])

  const handleZoomIn = () => setZoom((prev) => Math.min(prev * 1.2, 3))
  const handleZoomOut = () => setZoom((prev) => Math.max(prev / 1.2, 0.3))
  const handleReset = () => {
    setZoom(1)
    setPan({ x: 0, y: 0 })
  }

  const handleFullscreen = () => {
    setIsFullscreen(!isFullscreen)
  }

  const handleExport = () => {
    if (!svgRef.current) return
    const svgData = new XMLSerializer().serializeToString(svgRef.current)
    const blob = new Blob([svgData], { type: "image/svg+xml" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "automata.svg"
    a.click()
    URL.revokeObjectURL(url)
  }

  const drawNode = (parent: SVGGElement, state: string, isHighlighted = false, isFinalState = false) => {
    const position = nodePositions[state]
    if (!position) return

    const isStart = state === automata.startState
    const isAccept = automata.acceptStates.includes(state)

    // Node group for easier interaction
    const nodeGroup = document.createElementNS("http://www.w3.org/2000/svg", "g")
    nodeGroup.setAttribute("cursor", readonly ? "default" : "move")
    nodeGroup.addEventListener("mousedown", (e) => {
      e.preventDefault()
      handleMouseDown(e as any, state)
    })

    // Animated glow ONLY for final states during auto-play
    if (isFinalState && isAccept && autoPlay) {
      const glowCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
      glowCircle.setAttribute("cx", position.x.toString())
      glowCircle.setAttribute("cy", position.y.toString())
      glowCircle.setAttribute("r", (50 + animationPhase * 8).toString())
      glowCircle.setAttribute("fill", "none")
      glowCircle.setAttribute("stroke", "#2563eb")
      glowCircle.setAttribute("stroke-width", "3")
      glowCircle.setAttribute("opacity", (0.7 - animationPhase * 0.15).toString())
      nodeGroup.appendChild(glowCircle)
    }

    // Blue highlight ONLY for final states
    if (isFinalState && isAccept) {
      const finalGlow = document.createElementNS("http://www.w3.org/2000/svg", "circle")
      finalGlow.setAttribute("cx", position.x.toString())
      finalGlow.setAttribute("cy", position.y.toString())
      finalGlow.setAttribute("r", "42")
      finalGlow.setAttribute("fill", "none")
      finalGlow.setAttribute("stroke", "#2563eb")
      finalGlow.setAttribute("stroke-width", "4")
      finalGlow.setAttribute("opacity", "0.5")
      nodeGroup.appendChild(finalGlow)
    }

    // Regular highlight glow (for non-final states)
    if (isHighlighted && !isAccept) {
      const glowCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
      glowCircle.setAttribute("cx", position.x.toString())
      glowCircle.setAttribute("cy", position.y.toString())
      glowCircle.setAttribute("r", "38")
      glowCircle.setAttribute("fill", "none")
      glowCircle.setAttribute("stroke", "#dc2626")
      glowCircle.setAttribute("stroke-width", "3")
      glowCircle.setAttribute("opacity", "0.6")
      nodeGroup.appendChild(glowCircle)
    }

    // Main circle
    const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
    circle.setAttribute("cx", position.x.toString())
    circle.setAttribute("cy", position.y.toString())
    circle.setAttribute("r", "30")

    let fillColor = "white"
    let strokeColor = "#374151"
    let strokeWidth = "2"

    // Color ONLY final states in blue
    if (isFinalState && isAccept) {
      fillColor = autoPlay ? "url(#animatedGradient)" : "#dbeafe"
      strokeColor = "#2563eb"
      strokeWidth = "4"
    } else if (isHighlighted && !isAccept) {
      fillColor = "#fecaca"
      strokeColor = "#dc2626"
      strokeWidth = "3"
    } else if (isStart) {
      fillColor = "#fef3c7"
      strokeColor = "#f59e0b"
      strokeWidth = "3"
    }

    circle.setAttribute("fill", fillColor)
    circle.setAttribute("stroke", strokeColor)
    circle.setAttribute("stroke-width", strokeWidth)
    nodeGroup.appendChild(circle)

    // Double circle ONLY for accept states (final states)
    if (isAccept) {
      const innerCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
      innerCircle.setAttribute("cx", position.x.toString())
      innerCircle.setAttribute("cy", position.y.toString())
      innerCircle.setAttribute("r", isFinalState ? "22" : "24")
      innerCircle.setAttribute("fill", "none")
      innerCircle.setAttribute("stroke", strokeColor)
      innerCircle.setAttribute("stroke-width", isFinalState ? "3" : strokeWidth)
      nodeGroup.appendChild(innerCircle)
    }

    // State label
    const text = document.createElementNS("http://www.w3.org/2000/svg", "text")
    text.setAttribute("x", position.x.toString())
    text.setAttribute("y", (position.y + 6).toString())
    text.setAttribute("text-anchor", "middle")
    text.setAttribute("font-family", "Arial, sans-serif")
    text.setAttribute("font-size", "14")
    text.setAttribute("font-weight", "bold")
    text.setAttribute("fill", isFinalState && isAccept ? "#1d4ed8" : isHighlighted ? "#dc2626" : "#374151")
    text.setAttribute("pointer-events", "none")
    text.textContent = state
    nodeGroup.appendChild(text)

    parent.appendChild(nodeGroup)

    // START ARROW - Always show for initial state
    if (isStart) {
      const startArrow = document.createElementNS("http://www.w3.org/2000/svg", "path")
      const startX = position.x - 70
      const startY = position.y
      const endX = position.x - 30
      const endY = position.y

      // Enhanced arrow with better visibility
      startArrow.setAttribute(
        "d",
        `M ${startX} ${startY} L ${endX} ${endY} M ${endX - 8} ${endY - 8} L ${endX} ${endY} L ${endX - 8} ${endY + 8}`,
      )
      startArrow.setAttribute("stroke", isFinalState && isAccept ? "#2563eb" : "#f59e0b")
      startArrow.setAttribute("stroke-width", "5")
      startArrow.setAttribute("fill", "none")
      startArrow.setAttribute("stroke-linecap", "round")
      parent.appendChild(startArrow)

      // START label with better positioning
      const startLabel = document.createElementNS("http://www.w3.org/2000/svg", "text")
      startLabel.setAttribute("x", (startX - 20).toString())
      startLabel.setAttribute("y", (startY - 20).toString())
      startLabel.setAttribute("text-anchor", "middle")
      startLabel.setAttribute("font-family", "Arial, sans-serif")
      startLabel.setAttribute("font-size", "14")
      startLabel.setAttribute("fill", isFinalState && isAccept ? "#2563eb" : "#f59e0b")
      startLabel.setAttribute("font-weight", "bold")
      startLabel.textContent = "START"
      parent.appendChild(startLabel)
    }

    // FINAL label ONLY for accept states during auto-play
    if (isAccept && autoPlay) {
      const finalLabel = document.createElementNS("http://www.w3.org/2000/svg", "text")
      finalLabel.setAttribute("x", position.x.toString())
      finalLabel.setAttribute("y", (position.y + 60).toString())
      finalLabel.setAttribute("text-anchor", "middle")
      finalLabel.setAttribute("font-family", "Arial, sans-serif")
      finalLabel.setAttribute("font-size", "12")
      finalLabel.setAttribute("fill", "#2563eb")
      finalLabel.setAttribute("font-weight", "bold")
      finalLabel.setAttribute("opacity", (0.8 + animationPhase * 0.2).toString())
      finalLabel.textContent = "FINAL"
      parent.appendChild(finalLabel)
    }
  }

  if (!automata) {
    return (
      <div
        className="border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center text-gray-500"
        style={{ width, height }}
      >
        No automata to display
      </div>
    )
  }

  const displayWidth = isFullscreen ? "100vw" : width
  const displayHeight = isFullscreen ? "100vh" : height

  return (
    <div
      className={`relative border rounded-lg bg-white ${isFullscreen ? "fixed inset-0 z-50" : ""}`}
      style={{ width: displayWidth, height: displayHeight }}
    >
      {!readonly && (
        <div className="absolute top-2 right-2 flex gap-1 z-10">
          <Button size="sm" variant="outline" onClick={handleZoomIn}>
            <ZoomIn className="w-3 h-3" />
          </Button>
          <Button size="sm" variant="outline" onClick={handleZoomOut}>
            <ZoomOut className="w-3 h-3" />
          </Button>
          <Button size="sm" variant="outline" onClick={handleReset}>
            <RotateCcw className="w-3 h-3" />
          </Button>
          <Button size="sm" variant="outline" onClick={handleFullscreen}>
            <Maximize2 className="w-3 h-3" />
          </Button>
          <Button size="sm" variant="outline" onClick={handleExport}>
            <Download className="w-3 h-3" />
          </Button>
        </div>
      )}

      <svg
        ref={svgRef}
        width="100%"
        height="100%"
        viewBox={`0 0 ${width} ${height}`}
        className={readonly ? "cursor-default" : "cursor-move"}
        onMouseDown={(e) => !draggedNode && handleMouseDown(e)}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />

      {!readonly && (
        <div className="absolute bottom-2 left-2 text-xs text-gray-500 bg-white px-2 py-1 rounded">
          Drag nodes to move • Drag background to pan • {finalStateHighlight ? "Blue = Final states" : ""}
        </div>
      )}

      {finalStateHighlight && automata.acceptStates.length > 0 && (
        <div className="absolute top-2 left-2 bg-blue-100 border border-blue-300 px-3 py-2 rounded text-sm">
          <div className="font-semibold text-blue-800">Final States Highlighted</div>
          <div className="text-blue-600">{autoPlay ? "Auto-Playing" : "Static View"}</div>
        </div>
      )}
    </div>
  )
}
