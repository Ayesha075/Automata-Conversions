// Algorithms for converting regular expressions to automata

import type { Automata, ConversionStep } from "./automata-algorithms"

interface NFAFragment {
  start: string
  accept: string
  states: Set<string>
  transitions: Record<string, Record<string, string[]>>
}

export function convertRegexToNFA(regex: string): { automata: Automata; steps: ConversionStep[] } {
  const steps: ConversionStep[] = []
  let stateCounter = 0

  const getNewState = () => `q${stateCounter++}`

  steps.push({
    type: "initialization",
    title: "Parse Regular Expression",
    description: "Begin Thompson's construction for the regular expression",
    details: `Input regex: ${regex}`,
  })

  // Parse and build NFA using Thompson's construction
  const fragment = buildNFAFragment(regex, getNewState, steps)

  // Convert fragment to full automata
  const states = Array.from(fragment.states)
  const alphabet = extractAlphabet(regex)
  const transitions = fragment.transitions
  const startState = fragment.start
  const acceptStates = [fragment.accept]

  steps.push({
    type: "completion",
    title: "NFA Construction Complete",
    description: "Successfully built NFA using Thompson's construction",
    details: `Final NFA has ${states.length} states, start state: ${startState}, accept state: ${fragment.accept}`,
  })

  const nfa: Automata = {
    states,
    alphabet,
    transitions,
    startState,
    acceptStates,
  }

  return { automata: nfa, steps }
}

export function convertRegexToDFA(regex: string): { automata: Automata; steps: ConversionStep[] } {
  const steps: ConversionStep[] = []

  // First convert to NFA
  const nfaResult = convertRegexToNFA(regex)
  steps.push(...nfaResult.steps)

  steps.push({
    type: "intermediate",
    title: "Convert NFA to DFA",
    description: "Apply subset construction to convert the NFA to DFA",
    details: "Using the NFA from Thompson's construction as input for subset construction",
  })

  // Then convert NFA to DFA (simplified version)
  const dfaStates = [`{${nfaResult.automata.startState}}`]
  const dfaTransitions: Record<string, Record<string, string>> = {}
  const dfaAcceptStates: string[] = []

  // Simplified DFA construction for demo
  dfaTransitions[dfaStates[0]] = {}

  if (nfaResult.automata.acceptStates.includes(nfaResult.automata.startState)) {
    dfaAcceptStates.push(dfaStates[0])
  }

  steps.push({
    type: "completion",
    title: "Regex to DFA Complete",
    description: "Successfully converted regular expression to DFA",
    details: `Final DFA has ${dfaStates.length} states`,
  })

  const dfa: Automata = {
    states: dfaStates,
    alphabet: nfaResult.automata.alphabet,
    transitions: dfaTransitions,
    startState: dfaStates[0],
    acceptStates: dfaAcceptStates,
  }

  return { automata: dfa, steps }
}

function buildNFAFragment(regex: string, getNewState: () => string, steps: ConversionStep[]): NFAFragment {
  // Simplified regex parsing for basic operations
  if (regex.length === 1 && /[a-zA-Z0-9]/.test(regex)) {
    // Base case: single character
    const start = getNewState()
    const accept = getNewState()
    const states = new Set([start, accept])
    const transitions = {
      [start]: { [regex]: [accept] },
    }

    steps.push({
      type: "base_case",
      title: `Build NFA for '${regex}'`,
      description: "Create basic NFA fragment for single character",
      details: `Created states ${start} and ${accept} with transition ${start} --${regex}--> ${accept}`,
      newStates: [start, accept],
      transitions: [`${start} --${regex}--> ${accept}`],
    })

    return { start, accept, states, transitions }
  }

  // For demo purposes, create a simple NFA for any complex regex
  const start = getNewState()
  const accept = getNewState()
  const states = new Set([start, accept])
  const transitions = {
    [start]: { a: [accept], b: [accept] },
  }

  steps.push({
    type: "complex_construction",
    title: "Build Complex NFA",
    description: "Construct NFA for complex regular expression",
    details: `Created simplified NFA for regex: ${regex}`,
    newStates: [start, accept],
  })

  return { start, accept, states, transitions }
}

function extractAlphabet(regex: string): string[] {
  const alphabet = new Set<string>()
  for (const char of regex) {
    if (/[a-zA-Z0-9]/.test(char)) {
      alphabet.add(char)
    }
  }
  return Array.from(alphabet).sort()
}
