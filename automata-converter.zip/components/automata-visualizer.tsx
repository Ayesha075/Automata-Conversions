"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { ZoomIn, ZoomOut, RotateCcw } from "lucide-react"

interface AutomataVisualizerProps {
  automata: any
  highlightedStates?: string[]
  highlightedTransitions?: string[]
}

export default function AutomataVisualizer({
  automata,
  highlightedStates = [],
  highlightedTransitions = [],
}: AutomataVisualizerProps) {
  const svgRef = useRef<SVGSVGElement>(null)
  const [zoom, setZoom] = useState(1)
  const [pan, setPan] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })

  useEffect(() => {
    if (!automata || !svgRef.current) return
    renderAutomata()
  }, [automata, highlightedStates, highlightedTransitions, zoom, pan])

  const renderAutomata = () => {
    if (!automata || !svgRef.current) return

    const svg = svgRef.current
    const width = 400
    const height = 300

    // Clear previous content
    svg.innerHTML = ""

    // Create main group for transformations
    const mainGroup = document.createElementNS("http://www.w3.org/2000/svg", "g")
    mainGroup.setAttribute("transform", `translate(${pan.x}, ${pan.y}) scale(${zoom})`)
    svg.appendChild(mainGroup)

    // Position states in a circle
    const states = automata.states
    const centerX = width / 2
    const centerY = height / 2
    const radius = Math.min(width, height) / 3

    const statePositions = {}
    states.forEach((state, index) => {
      const angle = (2 * Math.PI * index) / states.length
      statePositions[state] = {
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
      }
    })

    // Draw transitions (arrows)
    Object.entries(automata.transitions).forEach(([fromState, transitions]) => {
      Object.entries(transitions).forEach(([symbol, toStates]) => {
        const toStateArray = Array.isArray(toStates) ? toStates : [toStates]
        toStateArray.forEach((toState) => {
          drawTransition(mainGroup, fromState, toState, symbol, statePositions)
        })
      })
    })

    // Draw states (circles)
    states.forEach((state) => {
      drawState(mainGroup, state, statePositions[state], {
        isStart: state === automata.startState,
        isAccept: automata.acceptStates.includes(state),
        isHighlighted: highlightedStates.includes(state),
      })
    })
  }

  const drawState = (parent, state, position, options) => {
    const { isStart, isAccept, isHighlighted } = options

    // State circle
    const circle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
    circle.setAttribute("cx", position.x.toString())
    circle.setAttribute("cy", position.y.toString())
    circle.setAttribute("r", "25")
    circle.setAttribute("fill", isHighlighted ? "#3b82f6" : "white")
    circle.setAttribute("stroke", isStart ? "#ef4444" : "#374151")
    circle.setAttribute("stroke-width", isStart ? "3" : "2")
    parent.appendChild(circle)

    // Accept state (double circle)
    if (isAccept) {
      const innerCircle = document.createElementNS("http://www.w3.org/2000/svg", "circle")
      innerCircle.setAttribute("cx", position.x.toString())
      innerCircle.setAttribute("cy", position.y.toString())
      innerCircle.setAttribute("r", "20")
      innerCircle.setAttribute("fill", "none")
      innerCircle.setAttribute("stroke", "#374151")
      innerCircle.setAttribute("stroke-width", "2")
      parent.appendChild(innerCircle)
    }

    // State label
    const text = document.createElementNS("http://www.w3.org/2000/svg", "text")
    text.setAttribute("x", position.x.toString())
    text.setAttribute("y", (position.y + 5).toString())
    text.setAttribute("text-anchor", "middle")
    text.setAttribute("font-family", "monospace")
    text.setAttribute("font-size", "12")
    text.setAttribute("fill", isHighlighted ? "white" : "black")
    text.textContent = state
    parent.appendChild(text)

    // Start arrow
    if (isStart) {
      const startArrow = document.createElementNS("http://www.w3.org/2000/svg", "path")
      const startX = position.x - 40
      const startY = position.y
      const endX = position.x - 25
      const endY = position.y
      startArrow.setAttribute(
        "d",
        `M ${startX} ${startY} L ${endX} ${endY} M ${endX - 5} ${endY - 5} L ${endX} ${endY} L ${endX - 5} ${endY + 5}`,
      )
      startArrow.setAttribute("stroke", "#ef4444")
      startArrow.setAttribute("stroke-width", "2")
      startArrow.setAttribute("fill", "none")
      parent.appendChild(startArrow)
    }
  }

  const drawTransition = (parent, fromState, toState, symbol, positions) => {
    const from = positions[fromState]
    const to = positions[toState]

    if (fromState === toState) {
      // Self-loop
      const loopPath = document.createElementNS("http://www.w3.org/2000/svg", "path")
      const cx = from.x
      const cy = from.y - 40
      loopPath.setAttribute(
        "d",
        `M ${from.x} ${from.y - 25} Q ${cx - 20} ${cy} ${cx} ${cy} Q ${cx + 20} ${cy} ${from.x} ${from.y - 25}`,
      )
      loopPath.setAttribute("stroke", "#374151")
      loopPath.setAttribute("stroke-width", "2")
      loopPath.setAttribute("fill", "none")
      loopPath.setAttribute("marker-end", "url(#arrowhead)")
      parent.appendChild(loopPath)

      // Label
      const label = document.createElementNS("http://www.w3.org/2000/svg", "text")
      label.setAttribute("x", cx.toString())
      label.setAttribute("y", (cy - 5).toString())
      label.setAttribute("text-anchor", "middle")
      label.setAttribute("font-family", "monospace")
      label.setAttribute("font-size", "10")
      label.setAttribute("fill", "#374151")
      label.textContent = symbol
      parent.appendChild(label)
    } else {
      // Regular transition
      const dx = to.x - from.x
      const dy = to.y - from.y
      const length = Math.sqrt(dx * dx + dy * dy)
      const unitX = dx / length
      const unitY = dy / length

      const startX = from.x + 25 * unitX
      const startY = from.y + 25 * unitY
      const endX = to.x - 25 * unitX
      const endY = to.y - 25 * unitY

      const line = document.createElementNS("http://www.w3.org/2000/svg", "line")
      line.setAttribute("x1", startX.toString())
      line.setAttribute("y1", startY.toString())
      line.setAttribute("x2", endX.toString())
      line.setAttribute("y2", endY.toString())
      line.setAttribute("stroke", "#374151")
      line.setAttribute("stroke-width", "2")
      line.setAttribute("marker-end", "url(#arrowhead)")
      parent.appendChild(line)

      // Label
      const midX = (startX + endX) / 2
      const midY = (startY + endY) / 2
      const label = document.createElementNS("http://www.w3.org/2000/svg", "text")
      label.setAttribute("x", midX.toString())
      label.setAttribute("y", (midY - 5).toString())
      label.setAttribute("text-anchor", "middle")
      label.setAttribute("font-family", "monospace")
      label.setAttribute("font-size", "10")
      label.setAttribute("fill", "#374151")
      label.setAttribute("background", "white")
      label.textContent = symbol
      parent.appendChild(label)
    }

    // Add arrowhead marker if not exists
    if (!parent.querySelector("#arrowhead")) {
      const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs")
      const marker = document.createElementNS("http://www.w3.org/2000/svg", "marker")
      marker.setAttribute("id", "arrowhead")
      marker.setAttribute("markerWidth", "10")
      marker.setAttribute("markerHeight", "7")
      marker.setAttribute("refX", "9")
      marker.setAttribute("refY", "3.5")
      marker.setAttribute("orient", "auto")

      const polygon = document.createElementNS("http://www.w3.org/2000/svg", "polygon")
      polygon.setAttribute("points", "0 0, 10 3.5, 0 7")
      polygon.setAttribute("fill", "#374151")

      marker.appendChild(polygon)
      defs.appendChild(marker)
      parent.appendChild(defs)
    }
  }

  const handleMouseDown = (e) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y })
  }

  const handleMouseMove = (e) => {
    if (!isDragging) return
    setPan({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleZoomIn = () => setZoom((prev) => Math.min(prev * 1.2, 3))
  const handleZoomOut = () => setZoom((prev) => Math.max(prev / 1.2, 0.3))
  const handleReset = () => {
    setZoom(1)
    setPan({ x: 0, y: 0 })
  }

  if (!automata) {
    return (
      <div className="w-full h-64 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center text-gray-500">
        No automata to display
      </div>
    )
  }

  return (
    <div className="relative border rounded-lg bg-white">
      <div className="absolute top-2 right-2 flex gap-1 z-10">
        <Button size="sm" variant="outline" onClick={handleZoomIn}>
          <ZoomIn className="w-3 h-3" />
        </Button>
        <Button size="sm" variant="outline" onClick={handleZoomOut}>
          <ZoomOut className="w-3 h-3" />
        </Button>
        <Button size="sm" variant="outline" onClick={handleReset}>
          <RotateCcw className="w-3 h-3" />
        </Button>
      </div>

      <svg
        ref={svgRef}
        width="100%"
        height="300"
        viewBox="0 0 400 300"
        className="cursor-move"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      />
    </div>
  )
}
