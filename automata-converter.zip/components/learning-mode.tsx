"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Lightbulb, Target, CheckCircle } from "lucide-react"

export default function LearningMode() {
  const [completedTopics, setCompletedTopics] = useState(new Set())

  const topics = [
    {
      id: "nfa-basics",
      title: "NFA Fundamentals",
      description: "Understanding Nondeterministic Finite Automata",
      difficulty: "Beginner",
      content: `
Nondeterministic Finite Automata (NFA) are computational models that can be in multiple states simultaneously.

Key Properties:
• Can have multiple transitions for the same input symbol
• Can have epsilon (ε) transitions
• Accepts a string if ANY path leads to an accept state
• More intuitive to design than DFAs

Example: An NFA that accepts strings ending in 'ab'
States: {q0, q1, q2}
Start: q0
Accept: {q2}
Transitions:
- q0 --a,b--> q0 (stay in start state)
- q0 --a--> q1 (guess that 'ab' is starting)
- q1 --b--> q2 (complete 'ab' pattern)
      `,
    },
    {
      id: "subset-construction",
      title: "Subset Construction Algorithm",
      description: "Converting NFA to DFA step by step",
      difficulty: "Intermediate",
      content: `
The Subset Construction Algorithm converts an NFA to an equivalent DFA.

Algorithm Steps:
1. Start with the initial state of the NFA
2. For each state in the DFA (which represents a set of NFA states):
   - For each input symbol, find all reachable NFA states
   - Create a new DFA state for this set (if it doesn't exist)
   - Add a transition to this new state
3. Repeat until no new states are created
4. Mark DFA states as accepting if they contain any NFA accept state

Time Complexity: O(2^n) where n is the number of NFA states
Space Complexity: O(2^n) in the worst case
      `,
    },
    {
      id: "epsilon-closure",
      title: "Epsilon Closure",
      description: "Handling epsilon transitions in automata",
      difficulty: "Intermediate",
      content: `
Epsilon closure is the set of states reachable from a given state using only epsilon (ε) transitions.

Computing ε-closure(q):
1. Initialize closure = {q}
2. For each state s in closure:
   - Add all states reachable from s via ε-transitions
3. Repeat until no new states are added

Example:
If q0 --ε--> q1 --ε--> q2, then:
ε-closure(q0) = {q0, q1, q2}

This is crucial for converting ε-NFAs to DFAs.
      `,
    },
    {
      id: "thompson-construction",
      title: "Thompson's Construction",
      description: "Converting regular expressions to NFA",
      difficulty: "Advanced",
      content: `
Thompson's Construction builds an NFA from a regular expression using structural induction.

Base Cases:
• Empty string (ε): Single state that's both start and accept
• Single symbol (a): Two states with one transition labeled 'a'

Inductive Cases:
• Union (R1|R2): Create new start and accept states, connect with ε-transitions
• Concatenation (R1R2): Connect accept states of R1 to start state of R2 with ε
• Kleene Star (R*): Add ε-transitions for zero or more repetitions

The resulting NFA has exactly one start state and one accept state.
      `,
    },
  ]

  const toggleCompletion = (topicId) => {
    const newCompleted = new Set(completedTopics)
    if (newCompleted.has(topicId)) {
      newCompleted.delete(topicId)
    } else {
      newCompleted.add(topicId)
    }
    setCompletedTopics(newCompleted)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5" />
          <CardTitle>Learning Mode</CardTitle>
        </div>
        <CardDescription>Interactive tutorials and explanations for automata theory concepts</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="tutorials" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tutorials">Tutorials</TabsTrigger>
            <TabsTrigger value="examples">Examples</TabsTrigger>
            <TabsTrigger value="practice">Practice</TabsTrigger>
          </TabsList>

          <TabsContent value="tutorials" className="space-y-4">
            <div className="grid gap-4">
              {topics.map((topic) => (
                <Card key={topic.id} className="relative">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2">
                          <Lightbulb className="w-4 h-4" />
                          <CardTitle className="text-lg">{topic.title}</CardTitle>
                        </div>
                        <Badge
                          variant={
                            topic.difficulty === "Beginner"
                              ? "secondary"
                              : topic.difficulty === "Intermediate"
                                ? "default"
                                : "destructive"
                          }
                        >
                          {topic.difficulty}
                        </Badge>
                      </div>
                      <Button
                        variant={completedTopics.has(topic.id) ? "default" : "outline"}
                        size="sm"
                        onClick={() => toggleCompletion(topic.id)}
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        {completedTopics.has(topic.id) ? "Completed" : "Mark Complete"}
                      </Button>
                    </div>
                    <CardDescription>{topic.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <pre className="whitespace-pre-wrap text-sm text-gray-700 font-sans leading-relaxed">
                      {topic.content}
                    </pre>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="examples" className="space-y-4">
            <div className="grid gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Worked Examples
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold mb-2">Example 1: NFA to DFA Conversion</h4>
                    <p className="text-sm text-gray-700 mb-2">
                      Convert an NFA that accepts strings with 'ab' as a substring.
                    </p>
                    <Button variant="outline" size="sm">
                      Try This Example
                    </Button>
                  </div>

                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-semibold mb-2">Example 2: Regular Expression to NFA</h4>
                    <p className="text-sm text-gray-700 mb-2">
                      Build an NFA for the regular expression (a|b)*abb using Thompson's construction.
                    </p>
                    <Button variant="outline" size="sm">
                      Try This Example
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="practice" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Practice Problems</CardTitle>
                <CardDescription>Test your understanding with interactive exercises</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8 text-gray-500">
                  Practice problems coming soon! Use the conversion tools above to experiment with different automata.
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
